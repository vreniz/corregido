// reservation.service.js
// Data-access layer for reservations. Controllers call these instead of
// touching http directly, so endpoints live in exactly one place.

import { http } from "@api/http";

/** Fetch every reservation (admin view / base for user filtering). */
export const getReservations = () => http.get("/reservations");

/** Fetch reservations belonging to one user (server-side filter). */
export const getReservationsByUser = (userId) =>
  http.get(`/reservations?userId=${userId}`);

/** Create a reservation. */
export const createReservation = (data) =>
  http.post("/reservations", data);

/** Replace a reservation entirely (used by edit form). */
export const updateReservation = (id, data) =>
  http.put(`/reservations/${id}`, data);

/** Patch a single field, e.g. status changes (approve/reject/cancel). */
export const patchReservation = (id, data) =>
  http.patch(`/reservations/${id}`, data);

/** Remove a reservation. */
export const deleteReservation = (id) =>
  http.delete(`/reservations/${id}`);
