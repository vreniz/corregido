// spaces.controller.js
// Admin spaces management: render a table of spaces and handle create,
// edit, and delete through the shared modal. Small helpers keep handlers
// flat and within the target complexity range.

import { bindSidebar } from "@components/Sidebar";
import { openModal } from "@components/Modal";
import { spaceForm, readSpaceForm, validateSpace }
  from "@controllers/spaceForm";
import {
  getSpaces,
  createSpace,
  updateSpace,
  deleteSpace,
} from "@services/space.service";
import { showToast } from "@utils/toast";
import { icon } from "@utils/icon";

const state = { spaces: [] };

/** Status pill markup for the table. */
const statusPill = (status) => {
  const ok = status === "available";
  const cls = ok
    ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300"
    : "bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300";
  return `<span class="text-xs font-semibold px-2 py-1 rounded-full ${cls} capitalize">${status}</span>`;
};

/** One table row for a space. */
const row = (s) => `
  <tr class="border-t border-slate-100 dark:border-slate-800">
    <td class="px-4 py-3 font-medium">${s.name}</td>
    <td class="px-4 py-3 text-slate-500 dark:text-slate-400">${s.type}</td>
    <td class="px-4 py-3">${s.capacity}</td>
    <td class="px-4 py-3 text-slate-500 dark:text-slate-400">${s.location}</td>
    <td class="px-4 py-3">${statusPill(s.status)}</td>
    <td class="px-4 py-3">
      <div class="flex gap-1">
        <button data-edit="${s.id}" class="p-2 rounded-lg text-slate-600 hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-700 cursor-pointer">${icon("edit", "w-4 h-4")}</button>
        <button data-del="${s.id}" class="p-2 rounded-lg text-rose-600 hover:bg-rose-100 dark:hover:bg-rose-500/20 cursor-pointer">${icon("trash", "w-4 h-4")}</button>
      </div>
    </td>
  </tr>`;

/** Render the full spaces table and bind its row actions. */
const renderTable = () => {
  const container = document.querySelector("#spacesContainer");
  container.innerHTML = `
    <table class="w-full text-sm text-left">
      <thead class="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400">
        <tr>
          <th class="px-4 py-3 font-semibold">Name</th>
          <th class="px-4 py-3 font-semibold">Type</th>
          <th class="px-4 py-3 font-semibold">Capacity</th>
          <th class="px-4 py-3 font-semibold">Location</th>
          <th class="px-4 py-3 font-semibold">Status</th>
          <th class="px-4 py-3 font-semibold">Actions</th>
        </tr>
      </thead>
      <tbody>${state.spaces.map(row).join("")}</tbody>
    </table>`;
  bindRowActions();
};

/** Persist a new or edited space, then refresh. */
const saveSpace = async (data, editing, close) => {
  if (editing) {
    await updateSpace(editing.id, { ...editing, ...data });
    showToast("Space updated", "success");
  } else {
    await createSpace(data);
    showToast("Space created", "success");
  }
  close();
  await refresh();
};

/** Open the create/edit modal and bind submit. */
const openSpaceModal = (editing = null) => {
  const title = editing ? "Edit space" : "New space";
  const { close } = openModal(title, spaceForm(editing || {}));
  document.querySelector("#spaceForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const data = readSpaceForm();
    const error = validateSpace(data);
    if (error) return showToast(error, "error");
    await saveSpace(data, editing, close);
  });
};

/** Bind edit/delete buttons in each row. */
const bindRowActions = () => {
  document.querySelectorAll("[data-edit]").forEach((b) =>
    b.addEventListener("click", () => {
      const space = state.spaces.find((s) => s.id === Number(b.dataset.edit));
      openSpaceModal(space);
    }),
  );
  document.querySelectorAll("[data-del]").forEach((b) =>
    b.addEventListener("click", async () => {
      await deleteSpace(b.dataset.del);
      showToast("Space deleted", "info");
      await refresh();
    }),
  );
};

/** Reload spaces and re-render. */
const refresh = async () => {
  state.spaces = await getSpaces();
  renderTable();
};

export const spacesController = async () => {
  bindSidebar();
  document
    .querySelector("#newSpaceBtn")
    .addEventListener("click", () => openSpaceModal());
  try {
    await refresh();
  } catch {
    document.querySelector("#spacesContainer").innerHTML =
      `<p class="p-6 text-rose-600">Failed to load spaces.</p>`;
  }
};
