// reservations.controller.js
// Orchestrates the reservations page: load + filter + render cards, open
// the create/edit modal, and handle status actions (approve/reject/cancel)
// and delete. Each concern is a small function so the handlers stay flat.

import ReservationCard from "@components/ReservationCard";
import { bindSidebar } from "@components/Sidebar";
import { openModal } from "@components/Modal";
import {
  reservationForm,
  readReservationForm,
  validateReservation,
} from "@controllers/reservationForm";

import {
  getReservations,
  getReservationsByUser,
  createReservation,
  updateReservation,
  patchReservation,
  deleteReservation,
} from "@services/reservation.service";
import { getSpaces } from "@services/space.service";
import { getUsers } from "@services/user.service";

import { getSession } from "@/utils";
import { showToast } from "@utils/toast";
import { isDuplicate } from "@utils/reservation.utils";

// Module-scoped state for the current page render.
const state = { all: [], owners: {}, spaces: [], user: null };

/** Apply the search + date filters to the loaded list. */
const applyFilters = () => {
  const term = document.querySelector("#searchInput").value.toLowerCase();
  const date = document.querySelector("#dateFilter").value;
  return state.all.filter((r) => {
    const matchText =
      r.workspace.toLowerCase().includes(term) ||
      r.reason.toLowerCase().includes(term);
    const matchDate = !date || r.date === date;
    return matchText && matchDate;
  });
};

/** Render the (optionally filtered) list into the grid. */
const renderList = () => {
  const container = document.querySelector("#reservationsContainer");
  const list = applyFilters();
  container.innerHTML = list.length
    ? list
        .map((r, i) =>
          ReservationCard(r, state.user, state.owners[r.userId] || "", i),
        )
        .join("")
    : `<p class="text-slate-500 col-span-full">No reservations match your filters.</p>`;
  bindCardActions();
};

/** Fetch reservations scoped by role and the owner-name map for admins. */
const loadData = async () => {
  state.user = getSession();
  state.all =
    state.user.role === "admin"
      ? await getReservations()
      : await getReservationsByUser(state.user.id);
  state.spaces = await getSpaces();
  if (state.user.role === "admin") {
    const users = await getUsers();
    state.owners = Object.fromEntries(users.map((u) => [u.id, u.name]));
  }
};

/** Persist a new or edited reservation, with duplicate protection. */
const saveReservation = async (data, editing, close) => {
  if (isDuplicate(state.all, data, editing?.id ?? null)) {
    showToast("That space is already booked at this time.", "error");
    return;
  }
  if (editing) {
    await updateReservation(editing.id, { ...editing, ...data });
    showToast("Reservation updated", "success");
  } else {
    await createReservation({
      ...data,
      userId: state.user.id,
      status: "pending",
    });
    showToast("Reservation created", "success");
  }
  close();
  await refresh();
};

/** Open the create/edit modal and bind its submit handler. */
const openReservationModal = (editing = null) => {
  const title = editing ? "Edit reservation" : "New reservation";
  const { close } = openModal(title, reservationForm(state.spaces, editing || {}));

  document
    .querySelector("#reservationForm")
    .addEventListener("submit", async (e) => {
      e.preventDefault();
      const data = readReservationForm();
      const error = validateReservation(data);
      if (error) return showToast(error, "error");
      await saveReservation(data, editing, close);
    });
};

/** Map a card action to a status patch or deletion, then refresh. */
const handleAction = async (action, id) => {
  const reservation = state.all.find((r) => r.id === Number(id));
  const statusMap = { approve: "approved", reject: "rejected", cancel: "cancelled" };

  if (action === "edit") return openReservationModal(reservation);
  if (action === "delete") {
    await deleteReservation(id);
    showToast("Reservation deleted", "info");
    return refresh();
  }
  await patchReservation(id, { status: statusMap[action] });
  showToast(`Reservation ${statusMap[action]}`, "success");
  return refresh();
};

/** Delegate clicks on the action buttons within cards. */
const bindCardActions = () => {
  document.querySelectorAll("[data-action]").forEach((btn) => {
    btn.addEventListener("click", () =>
      handleAction(btn.dataset.action, btn.dataset.id),
    );
  });
};

/** Reload data from the API and re-render. */
const refresh = async () => {
  await loadData();
  renderList();
};

/** Wire the toolbar controls (search, date filter, clear, new). */
const bindToolbar = () => {
  document.querySelector("#searchInput").addEventListener("input", renderList);
  document.querySelector("#dateFilter").addEventListener("change", renderList);
  document.querySelector("#clearFilters").addEventListener("click", () => {
    document.querySelector("#searchInput").value = "";
    document.querySelector("#dateFilter").value = "";
    renderList();
  });
  document
    .querySelector("#newReservationBtn")
    .addEventListener("click", () => openReservationModal());
};

export const reservationsController = async () => {
  bindSidebar();
  bindToolbar();
  try {
    await refresh();
  } catch {
    document.querySelector("#reservationsContainer").innerHTML =
      `<p class="text-rose-600 col-span-full">Failed to load reservations.</p>`;
  }
};
