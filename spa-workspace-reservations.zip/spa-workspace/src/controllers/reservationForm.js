// reservationForm.js
// Builds the reservation form markup for the create/edit modal. Pure
// string building only; the controller binds the submit handler. Spaces
// populate the dropdown so reservations stay linked to real workspaces.

/** One <option>, pre-selected when it matches the editing value. */
const spaceOption = (space, selected) =>
  `<option value="${space.name}" ${space.name === selected ? "selected" : ""}>
     ${space.name} · ${space.type}
   </option>`;

/** A labelled input row. */
const field = (label, inputHtml) => `
  <label class="block">
    <span class="text-sm font-medium text-slate-700 dark:text-slate-300">${label}</span>
    ${inputHtml}
  </label>`;

const inputClass =
  "mt-1 w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 " +
  "bg-white dark:bg-slate-900 focus:ring-2 focus:ring-teal-500 outline-none transition";

/**
 * @param {object[]} spaces  available spaces for the dropdown
 * @param {object} [data]    existing reservation when editing
 */
export const reservationForm = (spaces, data = {}) => {
  const r = {
    workspace: data.workspace || "",
    date: data.date || "",
    startHour: data.startHour || "",
    endHour: data.endHour || "",
    reason: data.reason || "",
  };

  return `
    <form id="reservationForm" class="space-y-4" novalidate>
      ${field(
        "Workspace",
        `<select id="f_workspace" class="${inputClass}">
           <option value="" disabled ${r.workspace ? "" : "selected"}>Select a space…</option>
           ${spaces.map((s) => spaceOption(s, r.workspace)).join("")}
         </select>`,
      )}
      ${field("Date", `<input id="f_date" type="date" value="${r.date}" class="${inputClass}" />`)}
      <div class="grid grid-cols-2 gap-3">
        ${field("Start", `<input id="f_start" type="time" value="${r.startHour}" class="${inputClass}" />`)}
        ${field("End", `<input id="f_end" type="time" value="${r.endHour}" class="${inputClass}" />`)}
      </div>
      ${field(
        "Reason",
        `<input id="f_reason" type="text" value="${r.reason}"
          placeholder="e.g. Sprint planning" class="${inputClass}" />`,
      )}
      <button type="submit"
        class="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white
               font-semibold transition cursor-pointer">
        Save reservation
      </button>
    </form>`;
};

/** Read the form fields into a plain object. */
export const readReservationForm = () => ({
  workspace: document.querySelector("#f_workspace").value,
  date: document.querySelector("#f_date").value,
  startHour: document.querySelector("#f_start").value,
  endHour: document.querySelector("#f_end").value,
  reason: document.querySelector("#f_reason").value.trim(),
});

/** Validate required fields; returns an error message or null. */
export const validateReservation = (data) => {
  if (!data.workspace) return "Please select a workspace.";
  if (!data.date) return "Please choose a date.";
  if (!data.startHour || !data.endHour) return "Please set start and end times.";
  if (data.endHour <= data.startHour) return "End time must be after start.";
  if (!data.reason) return "Please add a reason.";
  return null;
};
