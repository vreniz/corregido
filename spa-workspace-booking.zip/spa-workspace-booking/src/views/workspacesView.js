import Layout from "@components/Layout";
import Topbar from "@components/Topbar";
import { icons } from "@utils/icons";
import { workspacesController } from "@controllers/workspace.controller";

// Admin-only workspaces management view. Table body and modal are filled
// by the controller.
export default function workspacesView() {
  setTimeout(workspacesController);

  const content = `
    ${Topbar("Workspaces", "Manage bookable spaces")}

    <div class="flex justify-end mb-5">
      <button id="newWorkspaceBtn"
        class="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white
               text-sm font-semibold hover:bg-indigo-700 transition cursor-pointer">
        ${icons.plus("w-5 h-5")} New workspace
      </button>
    </div>

    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
      <div class="overflow-x-auto">
        <table class="w-full text-sm">
          <thead class="bg-slate-50 dark:bg-slate-700/40 text-slate-500 dark:text-slate-300">
            <tr>
              <th class="text-left font-semibold px-5 py-3">Name</th>
              <th class="text-left font-semibold px-5 py-3">Type</th>
              <th class="text-left font-semibold px-5 py-3">Capacity</th>
              <th class="text-left font-semibold px-5 py-3">Location</th>
              <th class="text-left font-semibold px-5 py-3">Status</th>
              <th class="text-right font-semibold px-5 py-3">Actions</th>
            </tr>
          </thead>
          <tbody id="workspacesBody" class="divide-y divide-slate-100 dark:divide-slate-700">
            <tr><td colspan="6" class="text-center text-slate-400 py-10">Loading workspaces...</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <div id="modalMount"></div>`;

  return Layout("/workspaces", content);
}
