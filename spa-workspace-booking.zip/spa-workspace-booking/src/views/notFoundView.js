import { icons } from "@utils/icons";
import { isAuthenticated } from "@utils/session";

// 404 screen for unknown routes. The button sends the user to a sensible
// place depending on whether they are logged in.
export default function notFoundView() {
  const target = isAuthenticated() ? "/dashboard" : "/";

  return `
    <div class="min-h-screen flex flex-col items-center justify-center bg-slate-100 dark:bg-slate-900 px-4 text-center transition-colors">
      <div class="text-indigo-600 dark:text-indigo-400 mb-4">${icons.alert("w-16 h-16")}</div>
      <h1 class="text-7xl font-bold text-slate-800 dark:text-white">404</h1>
      <h2 class="text-xl font-semibold text-slate-700 dark:text-slate-200 mt-3">Page not found</h2>
      <p class="text-slate-500 dark:text-slate-400 mt-2 max-w-md">
        The route you tried to visit does not exist or was moved.
      </p>
      <a href="${target}" data-link
        class="mt-6 inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white
               px-6 py-3 rounded-xl font-semibold transition cursor-pointer">
        ${icons.home("w-5 h-5")} Back to safety
      </a>
    </div>`;
}
