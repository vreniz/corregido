import Layout from "@components/Layout";
import Topbar from "@components/Topbar";
import { getSession } from "@utils/session";
import { icons } from "@utils/icons";
import { reservationsController } from "@controllers/reservation.controller";

// Reservations view. The toolbar holds the search box, status + date
// filters and the "New" button. The list and modal are filled by the
// controller after data loads.
export default function reservationsView() {
  const user = getSession();
  const subtitle =
    user.role === "admin"
      ? "Showing all reservations"
      : "Showing only your reservations";

  setTimeout(reservationsController);

  const inputCls =
    "px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 " +
    "bg-white dark:bg-slate-800 text-slate-800 dark:text-white text-sm " +
    "focus:outline-none focus:ring-2 focus:ring-indigo-500";

  const content = `
    ${Topbar("Reservations", subtitle)}

    <div class="flex flex-col sm:flex-row sm:items-center gap-3 mb-6">
      <div class="relative flex-1">
        <span class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">${icons.search("w-5 h-5")}</span>
        <input id="searchInput" type="text" placeholder="Search by workspace or reason"
          class="w-full pl-10 pr-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600
                 bg-white dark:bg-slate-800 text-slate-800 dark:text-white text-sm
                 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
      </div>
      <select id="statusFilter" class="${inputCls}">
        <option value="">All statuses</option>
        <option value="pending">Pending</option>
        <option value="approved">Approved</option>
        <option value="rejected">Rejected</option>
        <option value="cancelled">Cancelled</option>
      </select>
      <input id="dateFilter" type="date" class="${inputCls}" />
      <button id="newReservationBtn"
        class="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white
               text-sm font-semibold hover:bg-indigo-700 transition cursor-pointer">
        ${icons.plus("w-5 h-5")} New
      </button>
    </div>

    <div id="reservationsList" class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
      <div class="col-span-full text-center text-slate-400 py-12">Loading reservations...</div>
    </div>

    <div id="modalMount"></div>`;

  return Layout("/reservations", content);
}
