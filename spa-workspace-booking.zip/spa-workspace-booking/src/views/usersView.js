import Layout from "@components/Layout";
import Topbar from "@components/Topbar";
import { usersController } from "@controllers/users.controller";

// Admin-only view listing registered users. Read-only; passwords are
// never shown. The table body is populated by the controller.
export default function usersView() {
  setTimeout(usersController);

  const content = `
    ${Topbar("Users", "Registered accounts")}

    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
      <div class="overflow-x-auto">
        <table class="w-full text-sm">
          <thead class="bg-slate-50 dark:bg-slate-700/40 text-slate-500 dark:text-slate-300">
            <tr>
              <th class="text-left font-semibold px-5 py-3">ID</th>
              <th class="text-left font-semibold px-5 py-3">Name</th>
              <th class="text-left font-semibold px-5 py-3">Email</th>
              <th class="text-left font-semibold px-5 py-3">Role</th>
            </tr>
          </thead>
          <tbody id="usersBody" class="divide-y divide-slate-100 dark:divide-slate-700">
            <tr><td colspan="4" class="text-center text-slate-400 py-10">Loading users...</td></tr>
          </tbody>
        </table>
      </div>
    </div>`;

  return Layout("/users", content);
}
