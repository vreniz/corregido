import Layout from "@components/Layout";
import Topbar from "@components/Topbar";
import { getSession } from "@utils/session";
import { dashboardController } from "@controllers/dashboard.controller";

// Dashboard view: greeting + statistics grid. Numbers are filled by the
// controller after the reservation data loads.
export default function dashboardView() {
  const user = getSession();
  setTimeout(dashboardController);

  const content = `
    ${Topbar("Dashboard", `Welcome back, ${user?.name}`)}

    <div id="statsGrid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      <div class="col-span-full text-center text-slate-400 py-8">Loading statistics...</div>
    </div>

    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6">
      <h3 class="font-bold text-slate-800 dark:text-white mb-4">Reservations by status</h3>
      <div id="statusBars" class="space-y-3"></div>
    </div>`;

  return Layout("/dashboard", content);
}
