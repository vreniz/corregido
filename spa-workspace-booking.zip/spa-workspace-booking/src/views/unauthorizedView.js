import { icons } from "@utils/icons";

// Access-denied screen shown when a non-admin user tries to open an
// admin-only route. Offers a way back to their dashboard.
export default function unauthorizedView() {
  return `
    <div class="min-h-screen flex flex-col items-center justify-center bg-slate-100 dark:bg-slate-900 px-4 text-center transition-colors">
      <div class="text-rose-500 mb-4">${icons.ban("w-16 h-16")}</div>
      <h1 class="text-7xl font-bold text-slate-800 dark:text-white">403</h1>
      <h2 class="text-xl font-semibold text-slate-700 dark:text-slate-200 mt-3">Access denied</h2>
      <p class="text-slate-500 dark:text-slate-400 mt-2 max-w-md">
        You do not have permission to view this page. This area is reserved for administrators.
      </p>
      <a href="/dashboard" data-link
        class="mt-6 inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white
               px-6 py-3 rounded-xl font-semibold transition cursor-pointer">
        ${icons.home("w-5 h-5")} Go to dashboard
      </a>
    </div>`;
}
