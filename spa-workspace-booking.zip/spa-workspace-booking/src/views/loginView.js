import { loginController } from "@controllers/login.controller";
import { icons } from "@utils/icons";

// Login screen. The controller is wired up on the next tick so the markup
// already exists in the DOM when listeners attach.
export default function loginView() {
  setTimeout(loginController);

  return `
    <div class="min-h-screen flex items-center justify-center bg-slate-100 dark:bg-slate-900 p-4 transition-colors">
      <div class="animate-fade-in-up w-full max-w-md">
        <div class="text-center mb-6">
          <div class="inline-flex w-14 h-14 rounded-2xl bg-indigo-600 text-white items-center justify-center mb-3">
            ${icons.layers("w-7 h-7")}
          </div>
          <h1 class="text-2xl font-bold text-slate-800 dark:text-white">WorkSpace Booking</h1>
          <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Sign in to manage your reservations</p>
        </div>

        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 p-7">
          <form id="loginForm" class="space-y-4" novalidate>
            <div>
              <label class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Email</label>
              <div class="relative">
                <span class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">${icons.mail("w-5 h-5")}</span>
                <input type="email" name="email" autocomplete="username" placeholder="admin@test.com"
                  class="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600
                         bg-white dark:bg-slate-900 text-slate-800 dark:text-white text-sm
                         focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
            </div>

            <div>
              <label class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Password</label>
              <div class="relative">
                <span class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">${icons.lock("w-5 h-5")}</span>
                <input type="password" name="password" autocomplete="current-password" placeholder="••••••••"
                  class="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600
                         bg-white dark:bg-slate-900 text-slate-800 dark:text-white text-sm
                         focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
            </div>

            <button id="loginBtn" type="submit"
              class="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-indigo-600 text-white
                     text-sm font-semibold hover:bg-indigo-700 transition cursor-pointer
                     disabled:opacity-70 disabled:cursor-not-allowed">
              <span id="loginBtnText">Sign in</span>
            </button>
          </form>

          <div class="mt-5 pt-4 border-t border-slate-100 dark:border-slate-700 text-xs text-slate-400 text-center">
            Demo: admin@test.com / Admin123* &nbsp;·&nbsp; user@test.com / User123*
          </div>
        </div>
      </div>
    </div>`;
}
