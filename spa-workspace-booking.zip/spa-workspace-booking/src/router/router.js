import loginView from "@views/loginView";
import dashboardView from "@views/dashboardView";
import reservationsView from "@views/reservationsView";
import workspacesView from "@views/workspacesView";
import usersView from "@views/usersView";
import notFoundView from "@views/notFoundView";
import unauthorizedView from "@views/unauthorizedView";
import { isAuthenticated, isAdmin } from "@utils/session";

// Route table. `auth` marks protected routes; `role` restricts a route
// to a specific role (used as a simulated guard). Public routes omit both.
const routes = {
  "/": { view: loginView, auth: false },
  "/dashboard": { view: dashboardView, auth: true },
  "/reservations": { view: reservationsView, auth: true },
  "/workspaces": { view: workspacesView, auth: true, role: "admin" },
  "/users": { view: usersView, auth: true, role: "admin" },
};

// Programmatic navigation using the History API (no page reload).
export const navigateTo = (path) => {
  history.pushState({}, "", path);
  router();
};

// Decides which view to render for the current pathname, applying guards.
// Returns a render function so the main router stays flat and readable.
const resolveView = (path) => {
  const route = routes[path];

  // Unknown path -> 404.
  if (!route) return notFoundView;

  // Authenticated user landing on the login page -> send to dashboard.
  if (path === "/" && isAuthenticated()) {
    navigateTo("/dashboard");
    return null;
  }

  // Protected route without a session -> bounce to login.
  if (route.auth && !isAuthenticated()) {
    navigateTo("/");
    return null;
  }

  // Role guard: a non-admin hitting an admin route -> unauthorized screen.
  if (route.role === "admin" && !isAdmin()) {
    return unauthorizedView;
  }

  return route.view;
};

// Core router: clears the container and mounts the resolved view.
export const router = () => {
  const app = document.querySelector("#app");
  const path = window.location.pathname;
  const view = resolveView(path);

  // A redirect already triggered another router() call; stop here.
  if (!view) return;

  app.innerHTML = view();
};

// Intercept clicks on internal links so navigation stays within the SPA.
document.addEventListener("click", (e) => {
  const link = e.target.closest("[data-link]");
  if (!link) return;
  e.preventDefault();
  navigateTo(link.getAttribute("href"));
});

// Handle browser back/forward buttons.
window.addEventListener("popstate", router);
