import Modal from "@components/Modal";
import ReservationForm from "@components/ReservationForm";
import { getAvailableWorkspaces } from "@services/workspace.service";
import {
  createReservation,
  updateReservation,
  hasConflict,
} from "@services/reservation.service";
import { getSession } from "@utils/session";
import { showToast } from "@utils/toast";

// Removes the modal from the DOM.
const closeModal = () => {
  document.querySelector("#modalMount").innerHTML = "";
};

// Reads the form fields into a plain reservation payload, resolving the
// chosen workspace so we can store its name alongside the id.
const readForm = (form, workspaces) => {
  const wsId = Number(form.workspaceId.value);
  const ws = workspaces.find((w) => w.id === wsId);
  return {
    workspaceId: wsId,
    workspace: ws ? ws.name : "",
    date: form.date.value,
    startHour: form.startHour.value,
    endHour: form.endHour.value,
    reason: form.reason.value.trim(),
  };
};

// Validates the time range. Returns an error string or null when valid.
const validateRange = (payload) =>
  payload.endHour <= payload.startHour
    ? "End time must be after start time"
    : null;

// Persists the reservation (create or edit) after running the rules.
const persist = async (payload, existing, onDone) => {
  const conflict = await hasConflict(payload, existing?.id || null);
  if (conflict) {
    showToast("That workspace is already booked for this slot", "error");
    return;
  }

  if (existing) {
    await updateReservation(existing.id, { ...existing, ...payload });
    showToast("Reservation updated", "success");
  } else {
    const user = getSession();
    await createReservation({
      ...payload,
      userId: user.id,
      userName: user.name,
      status: "pending",
    });
    showToast("Reservation created", "success");
  }
  closeModal();
  onDone();
};

// Attaches submit/close handlers once the modal markup is in the DOM.
const wireModal = (workspaces, existing, onDone) => {
  document.querySelector("#modalClose").onclick = closeModal;
  document.querySelector("#cancelForm").onclick = closeModal;

  document.querySelector("#reservationForm").onsubmit = async (e) => {
    e.preventDefault();
    const payload = readForm(e.target, workspaces);

    const rangeError = validateRange(payload);
    if (rangeError) {
      showToast(rangeError, "warning");
      return;
    }

    try {
      await persist(payload, existing, onDone);
    } catch (error) {
      console.error(error);
      showToast("Could not save the reservation", "error");
    }
  };
};

// Opens the create/edit modal. `existing` is null for create.
export const openReservationModal = async (existing, onDone) => {
  try {
    const workspaces = await getAvailableWorkspaces();
    const title = existing ? "Edit reservation" : "New reservation";
    document.querySelector("#modalMount").innerHTML = Modal(
      title,
      ReservationForm(workspaces, existing || {}),
    );
    wireModal(workspaces, existing, onDone);
  } catch (error) {
    console.error(error);
    showToast("Could not load workspaces", "error");
  }
};
