import { getReservations } from "@services/reservation.service";
import { getSession } from "@utils/session";
import { initLayout } from "@controllers/layout.controller";
import { statusBadge, statusLabel } from "@utils/format";
import { icons } from "@utils/icons";
import { showToast } from "@utils/toast";

const STATUSES = ["pending", "approved", "rejected", "cancelled"];

// Returns only the reservations the current user is allowed to see.
const scopeReservations = (all, user) =>
  user.role === "admin" ? all : all.filter((r) => r.userId === user.id);

// Builds one stat card.
const statCard = (label, value, icon, color) => `
  <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5">
    <div class="flex items-center justify-between">
      <div>
        <p class="text-sm text-slate-500 dark:text-slate-400">${label}</p>
        <p class="text-3xl font-bold text-slate-800 dark:text-white mt-1">${value}</p>
      </div>
      <div class="w-11 h-11 rounded-xl bg-${color}-100 dark:bg-${color}-500/15
                  text-${color}-600 dark:text-${color}-300 flex items-center justify-center">${icon}</div>
    </div>
  </div>`;

// Renders the four summary cards from a status-count map.
const renderStats = (counts, total) => {
  const grid = document.querySelector("#statsGrid");
  grid.innerHTML =
    statCard("Total", total, icons.calendar("w-5 h-5"), "indigo") +
    statCard("Approved", counts.approved, icons.check("w-5 h-5"), "emerald") +
    statCard("Pending", counts.pending, icons.clock("w-5 h-5"), "amber") +
    statCard("Rejected", counts.rejected, icons.ban("w-5 h-5"), "rose");
};

// Renders a simple horizontal bar per status (lightweight chart).
const renderBars = (counts, total) => {
  const bars = document.querySelector("#statusBars");
  bars.innerHTML = STATUSES.map((s) => {
    const pct = total ? Math.round((counts[s] / total) * 100) : 0;
    return `
      <div>
        <div class="flex justify-between text-sm mb-1">
          <span class="font-medium px-2 py-0.5 rounded-full ${statusBadge(s)}">${statusLabel(s)}</span>
          <span class="text-slate-500 dark:text-slate-400">${counts[s]} (${pct}%)</span>
        </div>
        <div class="h-2 rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
          <div class="h-full bg-indigo-500 rounded-full transition-all" style="width:${pct}%"></div>
        </div>
      </div>`;
  }).join("");
};

// Counts reservations per status into a plain object.
const countByStatus = (list) => {
  const counts = { pending: 0, approved: 0, rejected: 0, cancelled: 0 };
  list.forEach((r) => {
    if (counts[r.status] !== undefined) counts[r.status] += 1;
  });
  return counts;
};

// Loads data, computes stats and paints the dashboard.
export const dashboardController = async () => {
  initLayout();
  try {
    const user = getSession();
    const all = await getReservations();
    const scoped = scopeReservations(all, user);
    const counts = countByStatus(scoped);
    renderStats(counts, scoped.length);
    renderBars(counts, scoped.length);
  } catch (error) {
    console.error(error);
    showToast("Failed to load statistics", "error");
  }
};
