import { login } from "@services/auth.service";
import { saveSession } from "@utils/session";
import { navigateTo } from "@router/router";
import { showToast } from "@utils/toast";
import { icons } from "@utils/icons";

// Switches the submit button into a disabled "loading" state immediately
// when the form is sent, so the user gets instant feedback.
const setLoading = (btn, textEl) => {
  btn.disabled = true;
  textEl.innerHTML = `${icons.clock("w-4 h-4 animate-spin-slow")} <span class="ml-1">Signing in...</span>`;
};

// Fully resets the form on failure and returns focus to the email field,
// matching the required UX behaviour.
const resetForm = (form, btn, textEl) => {
  form.reset();
  btn.disabled = false;
  textEl.textContent = "Sign in";
  form.email.focus();
};

// Wires up the login form: validation, loading state, auth and redirect.
export const loginController = () => {
  const form = document.querySelector("#loginForm");
  const btn = document.querySelector("#loginBtn");
  const textEl = document.querySelector("#loginBtnText");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = form.email.value.trim();
    const password = form.password.value.trim();

    // Basic client-side guard before hitting the API.
    if (!email || !password) {
      showToast("Please fill in all fields", "warning");
      return;
    }

    setLoading(btn, textEl);

    try {
      const user = await login(email, password);

      // Invalid credentials: clear everything and refocus email.
      if (!user) {
        showToast("Invalid credentials", "error");
        resetForm(form, btn, textEl);
        return;
      }

      // Store only the safe fields (never the password) in the session.
      saveSession({ id: user.id, name: user.name, role: user.role });
      showToast(`Welcome, ${user.name}`, "success");
      navigateTo("/dashboard");
    } catch (error) {
      console.error(error);
      showToast("Could not reach the API", "error");
      resetForm(form, btn, textEl);
    }
  });
};
