import { getUsers } from "@services/user.service";
import { initLayout } from "@controllers/layout.controller";
import { showToast } from "@utils/toast";

// Role badge classes for the users table.
const roleBadge = (role) =>
  role === "admin"
    ? "bg-indigo-100 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300"
    : "bg-slate-200 text-slate-600 dark:bg-slate-600/30 dark:text-slate-300";

// Builds one table row (password intentionally omitted).
const row = (u) => `
  <tr class="text-slate-700 dark:text-slate-200">
    <td class="px-5 py-3">${u.id}</td>
    <td class="px-5 py-3 font-medium">${u.name}</td>
    <td class="px-5 py-3">${u.email}</td>
    <td class="px-5 py-3">
      <span class="text-xs font-semibold px-2.5 py-1 rounded-full ${roleBadge(u.role)} capitalize">${u.role}</span>
    </td>
  </tr>`;

// Controller entry point: loads users and renders the table.
export const usersController = async () => {
  initLayout();
  try {
    const users = await getUsers();
    document.querySelector("#usersBody").innerHTML = users.map(row).join("");
  } catch (error) {
    console.error(error);
    showToast("Failed to load users", "error");
  }
};
