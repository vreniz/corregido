import Modal from "@components/Modal";
import WorkspaceForm from "@components/WorkspaceForm";
import {
  getWorkspaces,
  createWorkspace,
  updateWorkspace,
  deleteWorkspace,
} from "@services/workspace.service";
import { initLayout } from "@controllers/layout.controller";
import { icons } from "@utils/icons";
import { showToast } from "@utils/toast";

let cache = [];

// Removes the modal from the DOM.
const closeModal = () => {
  document.querySelector("#modalMount").innerHTML = "";
};

// Status pill markup for the table.
const statusPill = (status) => {
  const cls =
    status === "available"
      ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300"
      : "bg-slate-200 text-slate-600 dark:bg-slate-600/30 dark:text-slate-300";
  return `<span class="text-xs font-semibold px-2.5 py-1 rounded-full ${cls}">${status}</span>`;
};

// Builds a single table row with edit/delete buttons.
const row = (w) => `
  <tr class="text-slate-700 dark:text-slate-200">
    <td class="px-5 py-3 font-medium">${w.name}</td>
    <td class="px-5 py-3">${w.type}</td>
    <td class="px-5 py-3">${w.capacity}</td>
    <td class="px-5 py-3">${w.location}</td>
    <td class="px-5 py-3">${statusPill(w.status)}</td>
    <td class="px-5 py-3">
      <div class="flex justify-end gap-1">
        <button data-action="edit" data-id="${w.id}"
          class="p-2 rounded-lg text-indigo-600 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-500/15 transition cursor-pointer">
          ${icons.edit("w-4 h-4")}</button>
        <button data-action="delete" data-id="${w.id}"
          class="p-2 rounded-lg text-rose-600 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-500/15 transition cursor-pointer">
          ${icons.trash("w-4 h-4")}</button>
      </div>
    </td>
  </tr>`;

// Renders the table body from the cache.
const renderRows = () => {
  document.querySelector("#workspacesBody").innerHTML = cache
    .map(row)
    .join("");
};

// Reads the workspace form into a payload (capacity coerced to number).
const readForm = (form) => ({
  name: form.name.value.trim(),
  type: form.type.value,
  capacity: Number(form.capacity.value),
  location: form.location.value.trim(),
  status: form.status.value,
});

// Saves a workspace (create or edit) then refreshes the table.
const saveWorkspace = async (existing, payload) => {
  if (existing) {
    await updateWorkspace(existing.id, { ...existing, ...payload });
    showToast("Workspace updated", "success");
  } else {
    await createWorkspace(payload);
    showToast("Workspace created", "success");
  }
  closeModal();
  await load();
};

// Opens the create/edit modal and wires its handlers.
const openModal = (existing) => {
  const title = existing ? "Edit workspace" : "New workspace";
  document.querySelector("#modalMount").innerHTML = Modal(
    title,
    WorkspaceForm(existing || {}),
  );
  document.querySelector("#modalClose").onclick = closeModal;
  document.querySelector("#cancelForm").onclick = closeModal;
  document.querySelector("#workspaceForm").onsubmit = async (e) => {
    e.preventDefault();
    try {
      await saveWorkspace(existing, readForm(e.target));
    } catch (error) {
      console.error(error);
      showToast("Could not save the workspace", "error");
    }
  };
};

// Handles a table action (edit or delete).
const onTableClick = async (e) => {
  const btn = e.target.closest("[data-action]");
  if (!btn) return;
  const id = Number(btn.dataset.id);

  if (btn.dataset.action === "edit") {
    openModal(cache.find((w) => w.id === id));
    return;
  }
  try {
    await deleteWorkspace(id);
    showToast("Workspace deleted", "info");
    await load();
  } catch (error) {
    console.error(error);
    showToast("Could not delete the workspace", "error");
  }
};

// Loads workspaces into the cache and renders them.
const load = async () => {
  cache = await getWorkspaces();
  renderRows();
};

// Controller entry point for the admin workspaces view.
export const workspacesController = async () => {
  initLayout();
  document
    .querySelector("#newWorkspaceBtn")
    .addEventListener("click", () => openModal(null));
  document
    .querySelector("#workspacesBody")
    .addEventListener("click", onTableClick);

  try {
    await load();
  } catch (error) {
    console.error(error);
    showToast("Failed to load workspaces", "error");
  }
};
