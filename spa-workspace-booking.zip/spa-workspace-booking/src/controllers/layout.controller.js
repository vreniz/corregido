import { removeSession } from "@utils/session";
import { navigateTo } from "@router/router";
import { toggleTheme } from "@utils/theme";
import { showToast } from "@utils/toast";
import { icons } from "@utils/icons";

// Shared wiring for every authenticated page: logout button and the
// dark-mode toggle. Called by each view's controller after render.
export const initLayout = () => {
  // Logout clears the session completely and returns to the login page.
  document.querySelector("#logoutBtn")?.addEventListener("click", () => {
    removeSession();
    showToast("Signed out", "info");
    navigateTo("/");
  });

  // Theme toggle flips light/dark and swaps the button icon in place.
  const themeBtn = document.querySelector("#themeToggle");
  themeBtn?.addEventListener("click", () => {
    const theme = toggleTheme();
    themeBtn.innerHTML =
      theme === "dark" ? icons.sun("w-5 h-5") : icons.moon("w-5 h-5");
  });
};
