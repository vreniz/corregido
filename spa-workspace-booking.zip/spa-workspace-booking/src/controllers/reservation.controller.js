import ReservationCard from "@components/ReservationCard";
import { getReservations } from "@services/reservation.service";
import { getSession, isAdmin } from "@utils/session";
import { initLayout } from "@controllers/layout.controller";
import { openReservationModal } from "@controllers/reservation.modal";
import { handleAction } from "@controllers/reservation.actions";
import { showToast } from "@utils/toast";

// Module-level cache of the user's reservations so filtering does not
// require a new network request on every keystroke.
let allReservations = [];

// Restricts the dataset to the current user unless they are an admin.
const scope = (list, user) =>
  user.role === "admin" ? list : list.filter((r) => r.userId === user.id);

// Returns true when a reservation matches the current filter controls.
const matchesFilters = (r, term, status, date) => {
  const haystack = `${r.workspace} ${r.reason}`.toLowerCase();
  const okTerm = !term || haystack.includes(term);
  const okStatus = !status || r.status === status;
  const okDate = !date || r.date === date;
  return okTerm && okStatus && okDate;
};

// Renders the (possibly filtered) list, or an empty-state message.
const renderList = (list) => {
  const container = document.querySelector("#reservationsList");
  if (!list.length) {
    container.innerHTML = `
      <div class="col-span-full text-center text-slate-400 py-12">No reservations found</div>`;
    return;
  }
  container.innerHTML = list
    .map((r) => ReservationCard(r, isAdmin()))
    .join("");
};

// Reads the three filter controls and re-renders the matching subset.
const applyFilters = () => {
  const term = document.querySelector("#searchInput").value.trim().toLowerCase();
  const status = document.querySelector("#statusFilter").value;
  const date = document.querySelector("#dateFilter").value;
  renderList(
    allReservations.filter((r) => matchesFilters(r, term, status, date)),
  );
};

// Fetches data, caches the scoped list and renders it.
const loadReservations = async () => {
  const user = getSession();
  const all = await getReservations();
  allReservations = scope(all, user);
  applyFilters();
};

// Binds the toolbar controls and the delegated action handler.
const bindEvents = () => {
  document.querySelector("#searchInput").addEventListener("input", applyFilters);
  document.querySelector("#statusFilter").addEventListener("change", applyFilters);
  document.querySelector("#dateFilter").addEventListener("change", applyFilters);

  document
    .querySelector("#newReservationBtn")
    .addEventListener("click", () => openReservationModal(null, loadReservations));

  // One delegated listener handles every card button via data attributes.
  document.querySelector("#reservationsList").addEventListener("click", (e) => {
    const btn = e.target.closest("[data-action]");
    if (!btn) return;
    handleAction(btn.dataset.action, Number(btn.dataset.id), loadReservations);
  });
};

// Controller entry point for the reservations view.
export const reservationsController = async () => {
  initLayout();
  bindEvents();
  try {
    await loadReservations();
  } catch (error) {
    console.error(error);
    showToast("Failed to load reservations", "error");
  }
};
