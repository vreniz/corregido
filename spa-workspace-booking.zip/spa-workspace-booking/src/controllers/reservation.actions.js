import {
  getReservation,
  patchReservation,
  deleteReservation,
} from "@services/reservation.service";
import { openReservationModal } from "@controllers/reservation.modal";
import { showToast } from "@utils/toast";

// Maps a status-changing action to its patch payload + success message.
const STATUS_ACTIONS = {
  approve: { status: "approved", msg: "Reservation approved" },
  reject: { status: "rejected", msg: "Reservation rejected" },
  cancel: { status: "cancelled", msg: "Reservation cancelled" },
};

// Applies a status change through PATCH and refreshes the list.
const changeStatus = async (id, action, reload) => {
  const cfg = STATUS_ACTIONS[action];
  await patchReservation(id, { status: cfg.status });
  showToast(cfg.msg, "success");
  reload();
};

// Deletes a reservation entirely (admin only) and refreshes the list.
const removeReservation = async (id, reload) => {
  await deleteReservation(id);
  showToast("Reservation deleted", "info");
  reload();
};

// Opens the edit modal pre-filled with the reservation's current data.
const editReservation = async (id, reload) => {
  const reservation = await getReservation(id);
  openReservationModal(reservation, reload);
};

// Public dispatcher used by the list's delegated click handler.
// Keeps the switch flat to stay within the low-complexity target.
export const handleAction = async (action, id, reload) => {
  try {
    if (action === "edit") return editReservation(id, reload);
    if (action === "delete") return removeReservation(id, reload);
    if (STATUS_ACTIONS[action]) return changeStatus(id, action, reload);
  } catch (error) {
    console.error(error);
    showToast("Action failed", "error");
  }
};
