// Session helpers. Persistence is handled with localStorage so the
// session survives page refreshes until the user logs out explicitly.

const SESSION_KEY = "wb_user";

// Stores the authenticated user object as JSON.
export const saveSession = (user) => {
  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
};

// Returns the current user object, or null when there is no session.
export const getSession = () => {
  const raw = localStorage.getItem(SESSION_KEY);
  return raw ? JSON.parse(raw) : null;
};

// Removes every trace of the session (used on logout).
export const removeSession = () => {
  localStorage.removeItem(SESSION_KEY);
};

// True when a user is logged in.
export const isAuthenticated = () => Boolean(getSession());

// True when the logged-in user has the admin role.
export const isAdmin = () => getSession()?.role === "admin";
