// Theme helpers for the dark-mode feature.
// The chosen theme is stored in localStorage and applied to <html>.

const THEME_KEY = "wb_theme";

// Reads the saved theme, defaulting to "light".
export const getTheme = () => localStorage.getItem(THEME_KEY) || "light";

// Applies a theme by toggling the `dark` class on the root element.
export const applyTheme = (theme) => {
  const root = document.documentElement;
  root.classList.toggle("dark", theme === "dark");
  localStorage.setItem(THEME_KEY, theme);
};

// Flips between light and dark and returns the new value.
export const toggleTheme = () => {
  const next = getTheme() === "dark" ? "light" : "dark";
  applyTheme(next);
  return next;
};

// Called once on startup so the saved theme is active before rendering.
export const initTheme = () => applyTheme(getTheme());
