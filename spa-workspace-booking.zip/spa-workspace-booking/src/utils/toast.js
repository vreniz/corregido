import { icons } from "@utils/icons";

// Lightweight toast notifications. Each call appends a self-removing
// element into #toast-root. No external dependency required.

const COLORS = {
  success: "bg-emerald-500",
  error: "bg-rose-500",
  info: "bg-indigo-500",
  warning: "bg-amber-500",
};

const ICONS = {
  success: icons.check("w-5 h-5"),
  error: icons.alert("w-5 h-5"),
  info: icons.alert("w-5 h-5"),
  warning: icons.alert("w-5 h-5"),
};

// Shows a toast of a given type for a few seconds, then fades it out.
export const showToast = (message, type = "info") => {
  const root = document.querySelector("#toast-root");
  if (!root) return;

  const el = document.createElement("div");
  el.className = `animate-toast-in flex items-center gap-3 text-white px-4 py-3 rounded-xl shadow-lg mb-3 ${COLORS[type] || COLORS.info}`;
  el.innerHTML = `${ICONS[type] || ICONS.info}<span class="text-sm font-medium">${message}</span>`;
  root.appendChild(el);

  // Remove the toast automatically after the timeout.
  setTimeout(() => {
    el.style.transition = "opacity .3s ease";
    el.style.opacity = "0";
    setTimeout(() => el.remove(), 300);
  }, 3200);
};
