// Presentation helpers shared across views: maps reservation statuses
// to readable labels and Tailwind badge classes. Keeping this in one
// place avoids repeating colour logic in every component.

export const STATUS_LABELS = {
  pending: "Pending",
  approved: "Approved",
  rejected: "Rejected",
  cancelled: "Cancelled",
};

export const STATUS_BADGES = {
  pending:
    "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300",
  approved:
    "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300",
  rejected: "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300",
  cancelled:
    "bg-slate-200 text-slate-600 dark:bg-slate-600/30 dark:text-slate-300",
};

// Returns the badge classes for a status, falling back to a neutral style.
export const statusBadge = (status) =>
  STATUS_BADGES[status] || STATUS_BADGES.cancelled;

// Returns the readable label for a status.
export const statusLabel = (status) => STATUS_LABELS[status] || status;
