// A small inline SVG icon set. Returning strings keeps the components
// template-literal friendly and avoids any extra icon dependency.
// Each function accepts an optional className for sizing/colour.

const wrap = (cls, paths) =>
  `<svg xmlns="http://www.w3.org/2000/svg" class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;

export const icons = {
  calendar: (cls = "w-5 h-5") =>
    wrap(
      cls,
      `<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>`,
    ),
  clock: (cls = "w-5 h-5") =>
    wrap(cls, `<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>`),
  building: (cls = "w-5 h-5") =>
    wrap(
      cls,
      `<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M9 8h.01M15 8h.01M9 12h.01M15 12h.01M9 16h6"/>`,
    ),
  user: (cls = "w-5 h-5") =>
    wrap(cls, `<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>`),
  logout: (cls = "w-5 h-5") =>
    wrap(
      cls,
      `<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>`,
    ),
  plus: (cls = "w-5 h-5") => wrap(cls, `<path d="M12 5v14M5 12h14"/>`),
  edit: (cls = "w-5 h-5") =>
    wrap(
      cls,
      `<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>`,
    ),
  trash: (cls = "w-5 h-5") =>
    wrap(
      cls,
      `<path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>`,
    ),
  check: (cls = "w-5 h-5") => wrap(cls, `<path d="M20 6 9 17l-5-5"/>`),
  close: (cls = "w-5 h-5") => wrap(cls, `<path d="M18 6 6 18M6 6l12 12"/>`),
  ban: (cls = "w-5 h-5") =>
    wrap(cls, `<circle cx="12" cy="12" r="9"/><path d="m5 5 14 14"/>`),
  sun: (cls = "w-5 h-5") =>
    wrap(
      cls,
      `<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>`,
    ),
  moon: (cls = "w-5 h-5") =>
    wrap(cls, `<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/>`),
  home: (cls = "w-5 h-5") =>
    wrap(
      cls,
      `<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9 21v-6h6v6"/>`,
    ),
  chart: (cls = "w-5 h-5") =>
    wrap(cls, `<path d="M3 3v18h18"/><path d="M7 16v-5M12 16V8M17 16v-3"/>`),
  search: (cls = "w-5 h-5") =>
    wrap(cls, `<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>`),
  mail: (cls = "w-5 h-5") =>
    wrap(
      cls,
      `<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>`,
    ),
  lock: (cls = "w-5 h-5") =>
    wrap(
      cls,
      `<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>`,
    ),
  alert: (cls = "w-5 h-5") =>
    wrap(
      cls,
      `<path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/>`,
    ),
  layers: (cls = "w-5 h-5") =>
    wrap(
      cls,
      `<path d="m12 2 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5"/><path d="m3 17 9 5 9-5"/>`,
    ),
};
