import { icons } from "@utils/icons";
import { getTheme } from "@utils/theme";

// Top bar shown above every authenticated view. Includes the page title,
// a short subtitle and the dark-mode toggle button.
export default function Topbar(title, subtitle = "") {
  const isDark = getTheme() === "dark";

  return `
    <header class="flex items-center justify-between mb-8">
      <div>
        <h2 class="text-2xl font-bold text-slate-800 dark:text-white">${title}</h2>
        ${subtitle ? `<p class="text-sm text-slate-500 dark:text-slate-400 mt-1">${subtitle}</p>` : ""}
      </div>
      <button id="themeToggle" aria-label="Toggle theme"
        class="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-600
               bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300
               flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer">
        ${isDark ? icons.sun("w-5 h-5") : icons.moon("w-5 h-5")}
      </button>
    </header>`;
}
