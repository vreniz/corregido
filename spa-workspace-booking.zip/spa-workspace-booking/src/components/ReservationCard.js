import { icons } from "@utils/icons";
import { statusBadge, statusLabel } from "@utils/format";

// Returns the action buttons available for a reservation, based on role
// and the reservation status (encodes the business rules in the UI).
const buildActions = (r, isAdminUser) => {
  const buttons = [];

  // Admin can approve/reject pending reservations.
  if (isAdminUser && r.status === "pending") {
    buttons.push(actionBtn(r.id, "approve", icons.check("w-4 h-4"), "emerald"));
    buttons.push(actionBtn(r.id, "reject", icons.ban("w-4 h-4"), "rose"));
  }

  // Editing is allowed on pending reservations (admin can always edit).
  if (isAdminUser || r.status === "pending") {
    buttons.push(actionBtn(r.id, "edit", icons.edit("w-4 h-4"), "indigo"));
  }

  // Active reservations can be cancelled; admin can also delete outright.
  if (r.status === "pending" || r.status === "approved") {
    buttons.push(actionBtn(r.id, "cancel", icons.close("w-4 h-4"), "amber"));
  }
  if (isAdminUser) {
    buttons.push(actionBtn(r.id, "delete", icons.trash("w-4 h-4"), "slate"));
  }

  return buttons.join("");
};

// Small helper that builds one icon action button carrying data attributes
// the controller reads through event delegation.
const actionBtn = (id, action, icon, color) => `
  <button data-action="${action}" data-id="${id}"
    class="p-2 rounded-lg text-${color}-600 dark:text-${color}-300
           hover:bg-${color}-100 dark:hover:bg-${color}-500/15 transition cursor-pointer">
    ${icon}
  </button>`;

// Renders a single reservation card.
export default function ReservationCard(reservation, isAdminUser) {
  const { workspace, date, startHour, endHour, reason, status, userName } =
    reservation;

  return `
    <article class="animate-fade-in-up bg-white dark:bg-slate-800 rounded-2xl border border-slate-200
                    dark:border-slate-700 p-5 shadow-sm hover:shadow-md transition">
      <div class="flex items-start justify-between gap-3 mb-3">
        <div class="flex items-center gap-2 text-slate-800 dark:text-white">
          ${icons.building("w-5 h-5 text-indigo-600 dark:text-indigo-400")}
          <h3 class="font-bold text-lg">${workspace}</h3>
        </div>
        <span class="text-xs font-semibold px-2.5 py-1 rounded-full ${statusBadge(status)}">
          ${statusLabel(status)}
        </span>
      </div>

      <div class="space-y-2 text-sm text-slate-600 dark:text-slate-300">
        <p class="flex items-center gap-2">${icons.calendar("w-4 h-4")} ${date}</p>
        <p class="flex items-center gap-2">${icons.clock("w-4 h-4")} ${startHour} - ${endHour}</p>
        <p class="flex items-center gap-2">${icons.user("w-4 h-4")} ${userName}</p>
        <p class="text-slate-500 dark:text-slate-400 italic">"${reason}"</p>
      </div>

      <div class="flex items-center justify-end gap-1 mt-4 pt-3 border-t border-slate-100 dark:border-slate-700">
        ${buildActions(reservation, isAdminUser)}
      </div>
    </article>`;
}
