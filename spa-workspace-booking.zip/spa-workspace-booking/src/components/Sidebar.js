import { icons } from "@utils/icons";
import { getSession, isAdmin } from "@utils/session";

// Builds a single nav link, highlighting it when it matches the current path.
const navLink = (href, label, icon, active) => `
  <a href="${href}" data-link
     class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition
            ${
              active
                ? "bg-indigo-600 text-white shadow"
                : "text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-700/60"
            }">
    ${icon}
    <span>${label}</span>
  </a>`;

// Renders the sidebar. Admin-only links are appended conditionally so a
// regular user never sees restricted navigation entries.
export default function Sidebar(currentPath) {
  const user = getSession();

  let links = navLink(
    "/dashboard",
    "Dashboard",
    icons.chart("w-5 h-5"),
    currentPath === "/dashboard",
  );
  links += navLink(
    "/reservations",
    "Reservations",
    icons.calendar("w-5 h-5"),
    currentPath === "/reservations",
  );

  // Extra admin modules.
  if (isAdmin()) {
    links += navLink(
      "/workspaces",
      "Workspaces",
      icons.building("w-5 h-5"),
      currentPath === "/workspaces",
    );
    links += navLink(
      "/users",
      "Users",
      icons.user("w-5 h-5"),
      currentPath === "/users",
    );
  }

  return `
    <aside class="w-64 shrink-0 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700
                  flex flex-col h-screen sticky top-0 p-5">
      <div class="flex items-center gap-2 mb-8 px-1">
        <div class="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
          ${icons.layers("w-5 h-5")}
        </div>
        <h1 class="text-lg font-bold text-slate-800 dark:text-white">WorkSpace</h1>
      </div>

      <nav class="flex flex-col gap-1.5">${links}</nav>

      <div class="mt-auto">
        <div class="flex items-center gap-3 px-3 py-3 rounded-xl bg-slate-100 dark:bg-slate-700/50">
          <div class="w-9 h-9 rounded-full bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300
                      flex items-center justify-center">${icons.user("w-5 h-5")}</div>
          <div class="min-w-0">
            <p class="text-sm font-semibold text-slate-800 dark:text-white truncate">${user?.name || ""}</p>
            <p class="text-xs text-slate-500 dark:text-slate-400 capitalize">${user?.role || ""}</p>
          </div>
        </div>
        <button id="logoutBtn"
          class="mt-3 w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium
                 text-rose-600 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-500/10 transition cursor-pointer">
          ${icons.logout("w-5 h-5")} Log out
        </button>
      </div>
    </aside>`;
}
