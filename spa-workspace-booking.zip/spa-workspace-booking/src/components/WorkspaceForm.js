// Workspace form body for the admin "Workspaces" module. `data` pre-fills
// fields on edit; empty object means create.
const inputCls =
  "w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 " +
  "bg-white dark:bg-slate-900 text-slate-800 dark:text-white text-sm " +
  "focus:outline-none focus:ring-2 focus:ring-indigo-500";

const labelCls =
  "block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1";

const TYPES = ["Meeting Room", "Private Office", "Coworking Space", "Auditorium"];

// Builds type <option>s, marking the current selection.
const typeOptions = (selected) =>
  TYPES.map(
    (t) => `<option value="${t}" ${t === selected ? "selected" : ""}>${t}</option>`,
  ).join("");

export default function WorkspaceForm(data = {}) {
  return `
    <form id="workspaceForm" class="space-y-4">
      <div>
        <label class="${labelCls}">Name</label>
        <input type="text" name="name" value="${data.name || ""}" class="${inputCls}" required />
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label class="${labelCls}">Type</label>
          <select name="type" class="${inputCls}" required>${typeOptions(data.type)}</select>
        </div>
        <div>
          <label class="${labelCls}">Capacity</label>
          <input type="number" min="1" name="capacity" value="${data.capacity || ""}" class="${inputCls}" required />
        </div>
      </div>

      <div>
        <label class="${labelCls}">Location</label>
        <input type="text" name="location" value="${data.location || ""}" class="${inputCls}" required />
      </div>

      <div>
        <label class="${labelCls}">Status</label>
        <select name="status" class="${inputCls}">
          <option value="available" ${data.status === "available" ? "selected" : ""}>Available</option>
          <option value="unavailable" ${data.status === "unavailable" ? "selected" : ""}>Unavailable</option>
        </select>
      </div>

      <div class="flex justify-end gap-2 pt-2">
        <button type="button" id="cancelForm"
          class="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-300
                 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer">Cancel</button>
        <button type="submit"
          class="px-4 py-2 rounded-xl text-sm font-semibold bg-indigo-600 text-white
                 hover:bg-indigo-700 transition cursor-pointer">Save</button>
      </div>
    </form>`;
}
