import Sidebar from "@components/Sidebar";

// Application shell for authenticated pages. Wraps a view's inner content
// with the sidebar so individual views only describe their own body.
export default function Layout(currentPath, content) {
  return `
    <div class="flex min-h-screen bg-slate-100 dark:bg-slate-900 transition-colors">
      ${Sidebar(currentPath)}
      <main class="flex-1 p-6 sm:p-8 overflow-x-hidden">
        <div class="max-w-6xl mx-auto animate-fade-in-up">${content}</div>
      </main>
    </div>`;
}
