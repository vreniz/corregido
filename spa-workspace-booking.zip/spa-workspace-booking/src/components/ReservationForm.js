// Builds the reservation form body used inside the modal. `workspaces`
// fills the select; `data` pre-fills the fields when editing.
const inputCls =
  "w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 " +
  "bg-white dark:bg-slate-900 text-slate-800 dark:text-white text-sm " +
  "focus:outline-none focus:ring-2 focus:ring-indigo-500";

const labelCls =
  "block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1";

// Builds the <option> list for workspaces, marking the selected one.
const workspaceOptions = (workspaces, selectedId) =>
  workspaces
    .map(
      (w) =>
        `<option value="${w.id}" ${w.id === selectedId ? "selected" : ""}>${w.name}</option>`,
    )
    .join("");

export default function ReservationForm(workspaces, data = {}) {
  return `
    <form id="reservationForm" class="space-y-4">
      <div>
        <label class="${labelCls}">Workspace</label>
        <select name="workspaceId" class="${inputCls}" required>
          ${workspaceOptions(workspaces, data.workspaceId)}
        </select>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label class="${labelCls}">Date</label>
          <input type="date" name="date" value="${data.date || ""}" class="${inputCls}" required />
        </div>
        <div>
          <label class="${labelCls}">Start</label>
          <input type="time" name="startHour" value="${data.startHour || ""}" class="${inputCls}" required />
        </div>
        <div>
          <label class="${labelCls}">End</label>
          <input type="time" name="endHour" value="${data.endHour || ""}" class="${inputCls}" required />
        </div>
      </div>

      <div>
        <label class="${labelCls}">Reason</label>
        <input type="text" name="reason" value="${data.reason || ""}"
               placeholder="e.g. Sprint Planning" class="${inputCls}" required />
      </div>

      <div class="flex justify-end gap-2 pt-2">
        <button type="button" id="cancelForm"
          class="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-300
                 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer">Cancel</button>
        <button type="submit"
          class="px-4 py-2 rounded-xl text-sm font-semibold bg-indigo-600 text-white
                 hover:bg-indigo-700 transition cursor-pointer">Save</button>
      </div>
    </form>`;
}
