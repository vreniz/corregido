import { icons } from "@utils/icons";

// Generic modal shell. `bodyHtml` is the form/content injected by callers.
// Mounting/teardown is handled by the controllers that open it.
export default function Modal(title, bodyHtml) {
  return `
    <div id="modalOverlay"
      class="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4">
      <div class="animate-fade-in-up w-full max-w-lg bg-white dark:bg-slate-800 rounded-2xl shadow-xl
                  border border-slate-200 dark:border-slate-700">
        <div class="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-700">
          <h3 class="text-lg font-bold text-slate-800 dark:text-white">${title}</h3>
          <button id="modalClose"
            class="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer">
            ${icons.close("w-5 h-5")}
          </button>
        </div>
        <div class="p-5">${bodyHtml}</div>
      </div>
    </div>`;
}
