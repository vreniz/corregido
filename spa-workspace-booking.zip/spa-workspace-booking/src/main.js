import "@/style.css";
import { router } from "@router/router";
import { initTheme } from "@utils/theme";

// App bootstrap. Runs once the DOM is ready: applies the saved theme,
// then hands control to the router to render the first view.
document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  router();
});
