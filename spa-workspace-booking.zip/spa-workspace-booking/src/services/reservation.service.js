import { http } from "@api/http";

// Reservation service: all CRUD operations plus a duplicate-conflict check.
// Endpoints map directly to the json-server `reservations` collection.

export const getReservations = () => http.get("/reservations");

export const getReservation = (id) => http.get(`/reservations/${id}`);

export const createReservation = (data) =>
  http.post("/reservations", data);

export const updateReservation = (id, data) =>
  http.put(`/reservations/${id}`, data);

export const patchReservation = (id, data) =>
  http.patch(`/reservations/${id}`, data);

export const deleteReservation = (id) =>
  http.delete(`/reservations/${id}`);

// Business rule: no two active reservations may share the same workspace,
// date and start hour. Cancelled/rejected slots are considered free.
// `ignoreId` lets edits skip comparing the reservation against itself.
export const hasConflict = async (data, ignoreId = null) => {
  const all = await getReservations();
  return all.some((r) => {
    const sameSlot =
      r.workspaceId === data.workspaceId &&
      r.date === data.date &&
      r.startHour === data.startHour;
    const isActive = r.status === "pending" || r.status === "approved";
    const isOther = r.id !== ignoreId;
    return sameSlot && isActive && isOther;
  });
};
