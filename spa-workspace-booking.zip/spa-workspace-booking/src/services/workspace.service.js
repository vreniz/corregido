import { http } from "@api/http";

// Workspace service (extra-credit module). Workspaces are linked to
// reservations through `workspaceId`, so they have real meaning in the app.

export const getWorkspaces = () => http.get("/workspaces");

export const createWorkspace = (data) => http.post("/workspaces", data);

export const updateWorkspace = (id, data) =>
  http.put(`/workspaces/${id}`, data);

export const deleteWorkspace = (id) => http.delete(`/workspaces/${id}`);

// Returns only workspaces that are currently available for booking.
export const getAvailableWorkspaces = async () => {
  const all = await getWorkspaces();
  return all.filter((w) => w.status === "available");
};
