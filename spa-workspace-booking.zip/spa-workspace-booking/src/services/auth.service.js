import { http } from "@api/http";

// Authentication service. Validates credentials against json-server.
// Returns the matching user or null when credentials are invalid.
export const login = async (email, password) => {
  // json-server supports exact-match filtering via query params.
  const users = await http.get(
    `/users?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`,
  );
  return users.length ? users[0] : null;
};
