import { http } from "@api/http";

// User service. Used by the admin-only "Users" view to list registered
// accounts. Passwords are never displayed in the UI.
export const getUsers = () => http.get("/users");
