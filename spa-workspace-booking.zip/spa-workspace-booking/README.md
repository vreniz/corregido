# spa-workspace-booking

## Description

**WorkSpace Booking** is a Single Page Application (SPA) that lets a company
manage shared spaces (meeting rooms, private offices, coworking zones and
auditoriums). Employees can request reservations and administrators can manage
every reservation in the system.

The app is built with **Vanilla JavaScript + Vite** and consumes a simulated
REST API served by **json-server**. It implements authentication, role-based
authorization, session persistence, client-side routing with the History API,
and full CRUD over reservations (and, as an extra, over workspaces).

## Technologies

- **Vanilla JavaScript (ES Modules)** — application logic, no framework.
- **Vite** — development server and production bundler.
- **TailwindCSS v4** (`@tailwindcss/vite`) — utility-first styling and dark mode.
- **json-server** — mock REST API backed by `db.json`.
- **concurrently** — runs Vite and json-server together.
- **Fetch API** — HTTP communication with the backend.
- **History API** — clean client-side routing (no hash URLs).
- **localStorage** — session and theme persistence.

## Installation

```bash
# 1. Clone or download the repository
git clone <your-repo-url>
cd spa-workspace-booking

# 2. Install dependencies
npm install
```

## Running the Project

Start the Vite development server and the mock API at the same time:

```bash
npm run dev
```

- App: http://localhost:5173
- API: http://localhost:3001

You can also run them separately:

```bash
npm run vite     # only the frontend
npm run server   # only json-server
```

## Running JSON Server

The mock database lives in `db.json` at the project root. To run it on its own:

```bash
npx json-server --watch db.json --port 3001
```

Available resources:

- `http://localhost:3001/users`
- `http://localhost:3001/workspaces`
- `http://localhost:3001/reservations`

## Test Users

| Email           | Password   | Role  |
| --------------- | ---------- | ----- |
| admin@test.com  | Admin123\* | admin |
| user@test.com   | User123\*  | user  |
| user2@test.com  | User123\*  | user  |

## Project Structure

```
spa-workspace-booking/
├── db.json                       # Mock database (users, workspaces, reservations)
├── index.html                    # App entry point (#app + #toast-root)
├── package.json
├── vite.config.js                # Vite config + path aliases
├── public/
│   └── favicon.svg
└── src/
    ├── main.js                   # Bootstrap: theme + router
    ├── style.css                 # Tailwind import, dark variant, animations
    ├── api/
    │   └── http.js               # Fetch wrapper (base URL, headers, errors)
    ├── components/
    │   ├── Layout.js             # Sidebar + main shell
    │   ├── Sidebar.js            # Role-aware navigation
    │   ├── Topbar.js             # Title + dark-mode toggle
    │   ├── ReservationCard.js    # Reservation card + role-based actions
    │   ├── ReservationForm.js    # Create/edit reservation form body
    │   ├── WorkspaceForm.js      # Create/edit workspace form body
    │   └── Modal.js              # Generic modal shell
    ├── controllers/
    │   ├── login.controller.js       # Auth flow, loading state, reset-on-error
    │   ├── layout.controller.js      # Logout + theme toggle wiring
    │   ├── dashboard.controller.js   # Statistics computation + charts
    │   ├── reservation.controller.js # List, search, filters, event binding
    │   ├── reservation.modal.js      # Create/edit modal + business rules
    │   ├── reservation.actions.js    # Approve/reject/cancel/delete/edit
    │   ├── workspace.controller.js   # Admin workspace CRUD
    │   └── users.controller.js       # Admin user listing
    ├── router/
    │   └── router.js             # History API router + auth/role guards
    ├── services/
    │   ├── auth.service.js
    │   ├── reservation.service.js    # CRUD + conflict detection
    │   ├── workspace.service.js
    │   └── user.service.js
    ├── utils/
    │   ├── session.js            # localStorage session helpers
    │   ├── theme.js              # Dark-mode helpers
    │   ├── icons.js              # Inline SVG icon set
    │   ├── toast.js              # Toast notifications
    │   └── format.js             # Status labels + badge styles
    └── views/
        ├── loginView.js
        ├── dashboardView.js
        ├── reservationsView.js
        ├── workspacesView.js     # Admin only
        ├── usersView.js          # Admin only
        ├── notFoundView.js       # 404
        └── unauthorizedView.js   # 403
```

## Role Permissions

| Action                          | Admin | User                         |
| ------------------------------- | :---: | :--------------------------- |
| View dashboard                  |  ✅   | ✅ (own data only)           |
| View all reservations           |  ✅   | ❌                           |
| View own reservations           |  ✅   | ✅                           |
| Create reservation              |  ✅   | ✅                           |
| Edit reservation                |  ✅   | ✅ (own, while pending)      |
| Cancel reservation              |  ✅   | ✅ (own, pending/approved)   |
| Approve / reject reservation    |  ✅   | ❌                           |
| Delete reservation              |  ✅   | ❌                           |
| Manage workspaces (CRUD)        |  ✅   | ❌                           |
| View registered users           |  ✅   | ❌                           |
| Access `/workspaces`, `/users`  |  ✅   | ❌ (redirected to 403 view)  |

### Business rules enforced

- No two active reservations can share the same workspace, date and start hour.
- A user can only edit their own **pending** reservations.
- Approved reservations can only be cancelled, not edited (for users).
- The administrator can act on any reservation.

## Technical Decisions

- **History API routing.** Routing uses `history.pushState` and a `popstate`
  listener instead of hash URLs, producing clean paths (`/reservations`).
  Internal links carry a `data-link` attribute and are intercepted by a single
  delegated click handler, so navigation never reloads the page.

- **Simulated guards.** The route table declares `auth` and `role` flags. A
  `resolveView` function applies them before rendering: unauthenticated users
  are redirected to login, and non-admins hitting an admin route get a 403
  view. This keeps protection centralized in one place.

- **MVC-style modular architecture.** Responsibilities are split into
  `services` (API access), `controllers` (logic and DOM wiring), `views`
  (markup) and `components` (reusable UI). Each file stays small and focused,
  keeping cyclomatic complexity low and the code easy to test and explain.

- **State and session.** The session is stored in `localStorage` (only safe
  fields, never the password) so it survives refreshes; logout clears it
  completely. Reservation data is cached at module level on the reservations
  page so search and filters run instantly without extra requests.

- **Event delegation.** Card and table actions are handled by one listener per
  list using `data-action`/`data-id` attributes, avoiding many individual
  listeners and re-binding on every render.

- **Dark mode** is implemented with a Tailwind `@custom-variant` tied to a
  `dark` class on `<html>`, with the preference persisted in `localStorage` and
  applied before the first render to avoid a flash.

- **Extra features** included beyond the core spec: statistics dashboard, dark
  mode, search box, status and date filters, toast notifications, an icon set,
  the workspaces management module and the users listing module.
