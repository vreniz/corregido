# spa-workspace-reservations

A Single Page Application for booking shared company spaces — meeting rooms, private offices, coworking zones and auditoriums — with authentication, role-based access, and full CRUD over reservations.

## Description

WorkSpace Reservations lets employees reserve shared spaces and lets administrators manage every booking from one place. The app runs entirely in the browser as a SPA: navigation happens through the History API with no page reloads, the session persists in `localStorage`, and all data is served by a mock REST API (`json-server`).

Two roles are supported:

- **Admin** — full CRUD over any reservation, approve/reject pending requests, manage spaces and users, and view usage statistics.
- **User** — create reservations, view only their own, edit their pending ones, and cancel their own bookings.

## Technologies

- **JavaScript (Vanilla, ES Modules)** — application logic, no framework.
- **Vite 8** — dev server and bundler.
- **Tailwind CSS 4** (`@tailwindcss/vite`) — styling, class-based dark mode.
- **json-server** — mock REST API backed by `db.json`.
- **concurrently** — runs Vite and json-server together.
- **Fetch API** — HTTP requests to the mock API.
- **History API** — client-side routing (`pushState`, `popstate`).
- **localStorage** — session and theme persistence.

## Installation

```bash
# 1. Clone or download the project
git clone <your-repo-url> spa-workspace-reservations
cd spa-workspace-reservations

# 2. Install dependencies
npm install
```

## Running the Project

The `dev` script starts **both** the Vite dev server and json-server at once:

```bash
npm run dev
```

- App: http://localhost:5173
- API: http://localhost:3001

To run only the Vite dev server:

```bash
npm run build     # production build into /dist
npm run preview   # preview the production build
```

## Running JSON Server

The mock database lives in `db.json` and is served on port **3001**. It starts automatically with `npm run dev`, or you can run it on its own:

```bash
npm run server
# equivalent to:
npx json-server --watch db.json --port 3001
```

Available resources: `/users`, `/spaces`, `/reservations`.

## Test Users

| Role  | Email           | Password   |
|-------|-----------------|------------|
| Admin | admin@test.com  | Admin123*  |
| User  | user@test.com   | User123*   |
| User  | user2@test.com  | User123*   |

## Project Structure

```text
spa-workspace-reservations/
├── db.json                       # mock database (users, spaces, reservations)
├── index.html                    # SPA entry point + #app and #toast-root
├── package.json
├── vite.config.js                # Vite config + path aliases
├── README.md
├── public/
│   ├── favicon.svg
│   └── icons.svg                 # SVG sprite reused across the UI
└── src/
    ├── main.js                   # bootstrap: fonts, theme, router, links
    ├── style.css                 # Tailwind import, tokens, animations
    ├── utils.js                  # barrel re-exporting the util modules
    ├── api/
    │   └── http.js               # fetch wrapper with error handling
    ├── assets/                   # static logos/illustrations
    ├── components/
    │   ├── Layout.js             # sidebar + topbar shell
    │   ├── Sidebar.js            # role-aware nav, theme toggle, logout
    │   ├── ReservationCard.js    # reservation card + permission-aware actions
    │   └── Modal.js              # reusable modal (backdrop + panel)
    ├── controllers/
    │   ├── login.controller.js
    │   ├── home.controller.js
    │   ├── reservations.controller.js
    │   ├── reservationForm.js    # reservation form markup + validation
    │   ├── spaces.controller.js
    │   ├── spaceForm.js          # space form markup + validation
    │   ├── users.controller.js
    │   └── dashboard.controller.js
    ├── guards/
    │   └── auth.guard.js         # requireAuth + requireRole guards
    ├── router/
    │   └── router.js             # History API router + link interception
    ├── services/
    │   ├── auth.service.js
    │   ├── reservation.service.js
    │   ├── space.service.js
    │   └── user.service.js
    ├── utils/
    │   ├── session.js            # localStorage session helpers
    │   ├── theme.js              # dark-mode helpers
    │   ├── toast.js              # toast notifications
    │   ├── icon.js               # SVG sprite helper
    │   └── reservation.utils.js  # status labels + business-rule helpers
    └── views/
        ├── loginView.js
        ├── homeView.js
        ├── reservationsView.js
        ├── spacesView.js
        ├── usersView.js
        ├── dashboardView.js
        ├── unauthorized.js       # 403
        └── notFound.js           # 404
```

## Role Permissions

| Action                          | Admin | User                       |
|---------------------------------|:-----:|:--------------------------:|
| View all reservations           |  ✅   | ❌ (own only)              |
| View own reservations           |  ✅   | ✅                         |
| Create reservation              |  ✅   | ✅                         |
| Edit reservation                |  ✅   | ✅ (own + pending only)    |
| Cancel reservation              |  ✅   | ✅ (own, pending/approved) |
| Delete reservation              |  ✅   | ✅ (own only)              |
| Approve / reject reservation    |  ✅   | ❌                         |
| Manage spaces (CRUD)            |  ✅   | ❌                         |
| View users                      |  ✅   | ❌                         |
| View dashboard / statistics     |  ✅   | ❌                         |

Restricted routes (`/spaces`, `/users`, `/dashboard`) are protected by a role guard; a `user` who reaches them is redirected to a **403 Access Denied** page. Unauthenticated visitors are always redirected to the login page.

## Technical Decisions

- **History API routing.** Routing uses `history.pushState` and the `popstate` event instead of hash routing, giving clean URLs (`/home`, `/reservations`). A single delegated click listener intercepts `[data-link]` anchors so internal navigation never reloads the page.

- **Guards as a render step.** Each route may declare a guard (`requireAuth`, `requireRole`). The guard returns a redirect path when access is denied or `null` when allowed, and the router enforces it before rendering. This keeps access control declarative and in one table.

- **View / controller separation.** Views are pure functions returning HTML strings; controllers run after the markup is mounted and attach all event listeners and data loading. This keeps rendering predictable and makes the wiring easy to follow.

- **Modular, low-complexity functions.** Logic is split into small single-purpose helpers (form builders, validators, permission checks, render helpers) so each function stays within a low cyclomatic-complexity range and reads top to bottom.

- **Centralised session & theme.** All `localStorage` access is isolated in `utils/session.js` and `utils/theme.js`, so persistence can be changed in one place. The session survives refresh; logout clears it completely.

- **Pure business rules.** Permission logic (`canEdit`, `canCancel`, `canDelete`, `isDuplicate`) lives in pure helpers with no DOM or network access, so the same rules drive both the UI (which buttons show) and the save path (duplicate protection).

- **Single HTTP client.** Every request goes through one `fetch` wrapper that sets JSON headers, checks status, and normalises errors, so controllers handle failures with a simple `try/catch` + toast.

- **No build-time chart dependency.** The dashboard renders bar charts with plain styled `div`s, avoiding an extra library while still visualising status and space usage.

### Extra features included

- 🌙 Dark mode (class-based, persisted)
- 🔎 Live search + 📅 date filter on reservations
- 📊 Admin dashboard with statistics
- 🔔 Toast notifications
- 🛡️ 403 Unauthorized and 404 Not Found pages
- 🏢 Spaces management module (linked to reservations)
- 👥 Users module
- 📱 Responsive layout

---

© 2026 WorkSpace Reservations
