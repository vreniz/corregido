// space.service.js
// Data-access for workspaces/spaces. Read access is used everywhere
// (reservation form dropdown); write access is admin-only at the UI layer.

import { http } from "@api/http";

/** All spaces. */
export const getSpaces = () => http.get("/spaces");

/** Create a space (admin). */
export const createSpace = (data) => http.post("/spaces", data);

/** Update a space (admin). */
export const updateSpace = (id, data) =>
  http.put(`/spaces/${id}`, data);

/** Delete a space (admin). */
export const deleteSpace = (id) => http.delete(`/spaces/${id}`);
