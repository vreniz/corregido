// auth.service.js
// Authentication data-access. Validates credentials against json-server
// by querying users with a matching email + password.

import { http } from "@api/http";

/**
 * Look up a user by email + password. Returns the matched user or null.
 * json-server filters via query params, so we read the first match.
 */
export const login = async (email, password) => {
  const query = `/users?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`;
  const users = await http.get(query);
  return users.length ? users[0] : null;
};
