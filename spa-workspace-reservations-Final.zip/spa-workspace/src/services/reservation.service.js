// reservation.service.js
// Data-access layer for reservations. Controllers call these instead of
// touching http directly, so endpoints live in exactly one place.

import { http } from "@api/http";

/** Fetch every reservation (admin view / base for user filtering). */
export const getReservations = () => http.get("/reservations");

/**
 * Fetch reservations belonging to one user.
 * We fetch all and filter in JS with loose (==) comparison so it works
 * regardless of whether json-server stores userId as number or string.
 * This guarantees a user sees ALL their own reservations (pending,
 * approved, rejected, cancelled) the moment they are created.
 */
export const getReservationsByUser = async (userId) => {
  const all = await getReservations();
  return all.filter((r) => String(r.userId) === String(userId));
};

/** Create a reservation. */
export const createReservation = (data) =>
  http.post("/reservations", data);

/** Replace a reservation entirely (used by edit form). */
export const updateReservation = (id, data) =>
  http.put(`/reservations/${id}`, data);

/** Patch a single field, e.g. status changes (approve/reject/cancel). */
export const patchReservation = (id, data) =>
  http.patch(`/reservations/${id}`, data);

/** Remove a reservation. */
export const deleteReservation = (id) =>
  http.delete(`/reservations/${id}`);
