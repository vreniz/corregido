// user.service.js
// Read-only access to users, used by the admin "Users" view and to
// resolve userId -> name when rendering reservations as an admin.

import { http } from "@api/http";

/** Every registered user. */
export const getUsers = () => http.get("/users");
