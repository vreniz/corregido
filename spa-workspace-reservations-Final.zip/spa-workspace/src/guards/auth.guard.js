// auth.guard.js
// Simulated route guards. Each guard inspects the session and returns a
// redirect target (string) when access is denied, or null when allowed.
// The router consumes these before rendering a view.

import { isAuthenticated, getSession } from "@utils/session";

/**
 * Require a logged-in user. Anonymous visitors are sent to the login page.
 */
export const requireAuth = () => (isAuthenticated() ? null : "/");

/**
 * Require a specific role. Returns "/unauthorized" when the role does not
 * match, "/" when not logged in at all, or null when access is granted.
 */
export const requireRole = (role) => () => {
  if (!isAuthenticated()) return "/";
  return getSession()?.role === role ? null : "/unauthorized";
};
