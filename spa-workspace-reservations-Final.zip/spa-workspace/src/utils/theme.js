// theme.js
// Dark-mode handling. The preference lives in localStorage and is applied
// by toggling the `dark` class on <html>, which our @custom-variant reads.

const THEME_KEY = "ws_theme";

/** Read the stored theme, defaulting to light. */
export const getTheme = () => localStorage.getItem(THEME_KEY) || "light";

/**
 * Apply a theme to the document and persist it.
 * Centralised so both the initial load and the toggle use one path.
 */
export const applyTheme = (theme) => {
  const root = document.documentElement;
  root.classList.toggle("dark", theme === "dark");
  localStorage.setItem(THEME_KEY, theme);
};

/** Flip the current theme and return the new value. */
export const toggleTheme = () => {
  const next = getTheme() === "dark" ? "light" : "dark";
  applyTheme(next);
  return next;
};

/** Run once at startup to honour the saved preference. */
export const initTheme = () => applyTheme(getTheme());
