// reservation.utils.js
// Pure helpers for reservation status: labels, badge colours, and the
// business rules that decide which actions are allowed. Keeping these
// pure (no DOM, no fetch) keeps the controllers small and testable.

export const STATUS = {
  pending: "pending",
  approved: "approved",
  rejected: "rejected",
  cancelled: "cancelled",
};

/** Human label per status. */
export const statusLabel = (status) =>
  ({
    pending: "Pending",
    approved: "Approved",
    rejected: "Rejected",
    cancelled: "Cancelled",
  })[status] || status;

/** Tailwind badge classes per status (light + dark). */
export const statusBadge = (status) =>
  ({
    pending:
      "bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300",
    approved:
      "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300",
    rejected:
      "bg-rose-100 text-rose-800 dark:bg-rose-500/15 dark:text-rose-300",
    cancelled:
      "bg-slate-200 text-slate-700 dark:bg-slate-600/30 dark:text-slate-300",
  })[status] || "bg-slate-100 text-slate-700";

/**
 * Business rule: a user may EDIT only their own pending reservations.
 * Admins may edit anything. One clear boolean keeps callers simple.
 */
export const canEdit = (reservation, user) => {
  if (user.role === "admin") return true;
  return isOwner(reservation, user) && reservation.status === STATUS.pending;
};

/**
 * Business rule: a user may CANCEL their own pending or approved
 * reservations. Rejected/cancelled ones are terminal.
 */
export const canCancel = (reservation, user) => {
  if (!isOwner(reservation, user) && user.role !== "admin") return false;
  return [STATUS.pending, STATUS.approved].includes(reservation.status);
};

/**
 * Ownership check using loose string comparison, so it works whether the
 * API stores userId as a number or a string.
 */
export const isOwner = (reservation, user) =>
  String(reservation.userId) === String(user.id);

/**
 * Business rule: a user may DELETE only their own reservations;
 * admins may delete any. Used to guard the trash action.
 */
export const canDelete = (reservation, user) =>
  user.role === "admin" || isOwner(reservation, user);

/**
 * Duplicate check: same workspace + date + start hour already taken.
 * Optionally ignore one id (when editing an existing reservation).
 */
export const isDuplicate = (list, candidate, ignoreId = null) =>
  list.some(
    (r) =>
      r.id !== ignoreId &&
      r.workspace === candidate.workspace &&
      r.date === candidate.date &&
      r.startHour === candidate.startHour,
  );
