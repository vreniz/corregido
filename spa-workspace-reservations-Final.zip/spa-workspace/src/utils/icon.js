// icon.js
// Returns an <svg> string that references a symbol from /icons.svg.
// Using a sprite keeps markup tiny and lets icons inherit currentColor.

/**
 * @param {string} name  symbol id without the `i-` prefix (e.g. "calendar")
 * @param {string} cls   Tailwind classes for sizing/colour
 */
export const icon = (name, cls = "w-5 h-5") =>
  `<svg class="${cls}" aria-hidden="true"><use href="/icons.svg#i-${name}"></use></svg>`;
