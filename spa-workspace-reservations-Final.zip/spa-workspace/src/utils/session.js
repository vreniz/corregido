// session.js
// Thin wrapper around localStorage for the authenticated user.
// Keeping all storage access here means the rest of the app never
// touches localStorage directly, which makes the session easy to swap.

const SESSION_KEY = "ws_user";

/**
 * Persist the logged-in user. Called right after a successful login.
 */
export const saveSession = (user) => {
  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
};

/**
 * Read the current user, or null when nobody is logged in.
 * Wrapped in try/catch so a corrupted value never crashes the app.
 */
export const getSession = () => {
  try {
    return JSON.parse(localStorage.getItem(SESSION_KEY));
  } catch {
    return null;
  }
};

/**
 * Clear all session data. Used by logout.
 */
export const removeSession = () => {
  localStorage.removeItem(SESSION_KEY);
};

/** True when a session exists. */
export const isAuthenticated = () => Boolean(getSession());

/** True when the current user has the admin role. */
export const isAdmin = () => getSession()?.role === "admin";
