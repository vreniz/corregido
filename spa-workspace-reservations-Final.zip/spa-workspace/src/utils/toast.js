// toast.js
// Minimal toast system. Renders a dismissible card into #toast-root and
// auto-removes it. Exported helpers map to semantic colours.

import { icon } from "@utils/icon";

const COLORS = {
  success: "bg-emerald-600",
  error: "bg-rose-600",
  info: "bg-slate-800 dark:bg-slate-700",
};

const ICONS = {
  success: "check",
  error: "alert",
  info: "info",
};

/**
 * Show a toast. `type` selects colour + icon; it disappears after `ms`.
 * The exit animation runs before the node is removed from the DOM.
 */
export const showToast = (message, type = "info", ms = 3200) => {
  const root = document.querySelector("#toast-root");
  if (!root) return;

  const el = document.createElement("div");
  el.className =
    `toast-in flex items-center gap-3 ${COLORS[type] || COLORS.info} ` +
    "text-white px-4 py-3 rounded-xl shadow-lg max-w-xs";
  el.innerHTML = `${icon(ICONS[type] || "info", "w-5 h-5 shrink-0")}
    <span class="text-sm font-medium">${message}</span>`;

  root.appendChild(el);
  // Schedule the dismissal: animate out, then detach.
  setTimeout(() => {
    el.classList.replace("toast-in", "toast-out");
    el.addEventListener("animationend", () => el.remove(), { once: true });
  }, ms);
};

/** Mount a fixed container the first time a toast is requested. */
export const initToastRoot = () => {
  const root = document.querySelector("#toast-root");
  if (root) {
    root.className =
      "fixed top-5 right-5 z-[100] flex flex-col gap-2 items-end";
  }
};
