// Sidebar.js
// Navigation shell shared by every authenticated view. Renders role-aware
// links plus a theme toggle and logout. Returns markup only; the wiring is
// attached by `bindSidebar` once the markup is in the DOM.

import { getSession, isAdmin, removeSession } from "@/utils";
import { toggleTheme, getTheme } from "@utils/theme";
import { showToast } from "@utils/toast";
import { icon } from "@utils/icon";
import { navigateTo } from "@router/router";

/** One nav link. `data-link` lets the router intercept the click. */
const navLink = (href, label, ico) => `
  <a href="${href}" data-link
     class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium
            text-slate-300 hover:text-white hover:bg-white/10 transition-colors">
    ${icon(ico, "w-5 h-5")}
    <span>${label}</span>
  </a>`;

/** Admin-only links are concatenated only when the user is an admin. */
const adminLinks = () => `
  ${navLink("/dashboard", "Dashboard", "chart")}
  ${navLink("/spaces", "Spaces", "layers")}
  ${navLink("/users", "Users", "users")}`;

export default function Sidebar() {
  const user = getSession();
  const themeIcon = getTheme() === "dark" ? "sun" : "moon";

  return `
    <aside class="w-64 shrink-0 bg-slate-900 text-white min-h-screen
                  p-5 flex flex-col gap-6">
      <div class="flex items-center gap-2 px-1">
        ${icon("calendar", "w-7 h-7 text-teal-400")}
        <h2 class="text-xl font-bold tracking-tight">WorkSpace</h2>
      </div>

      <div class="px-3 py-3 rounded-xl bg-white/5">
        <p class="text-sm font-semibold truncate">${user?.name ?? "Guest"}</p>
        <p class="text-xs text-teal-400 capitalize">${user?.role ?? ""}</p>
      </div>

      <nav class="flex flex-col gap-1">
        ${navLink("/home", "Home", "home")}
        ${navLink("/reservations", "Reservations", "grid")}
        ${isAdmin() ? adminLinks() : ""}
      </nav>

      <div class="mt-auto flex flex-col gap-1">
        <button id="themeBtn"
          class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium
                 text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer">
          ${icon(themeIcon, "w-5 h-5")}
          <span>Toggle theme</span>
        </button>
        <button id="logoutBtn"
          class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium
                 text-rose-400 hover:text-white hover:bg-rose-500/80 transition-colors cursor-pointer">
          ${icon("logout", "w-5 h-5")}
          <span>Log out</span>
        </button>
      </div>
    </aside>`;
}

/**
 * Attach behaviour to the sidebar. Called by each view's controller after
 * render. Kept separate from markup so rendering stays a pure function.
 */
export const bindSidebar = () => {
  document.querySelector("#themeBtn")?.addEventListener("click", () => {
    toggleTheme();
    // Refresh the icon by re-running the current route's controller is
    // overkill; just swap the icon in place via a tiny re-render trigger.
    navigateTo(window.location.pathname);
  });

  document.querySelector("#logoutBtn")?.addEventListener("click", () => {
    removeSession();
    showToast("Signed out", "info");
    navigateTo("/");
  });
};
