// Modal.js
// Lightweight modal used for the reservation and space forms. Renders a
// backdrop + centered panel and provides open/close helpers that manage
// the DOM node and the exit animation.

import { icon } from "@utils/icon";

/**
 * Build modal markup. `bodyHtml` is the form/content; `title` is the header.
 */
export const modalTemplate = (title, bodyHtml) => `
  <div id="modalBackdrop"
       class="backdrop-in fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm
              flex items-center justify-center p-4">
    <div class="panel-in w-full max-w-md rounded-2xl bg-white dark:bg-slate-900
                shadow-xl border border-slate-200 dark:border-slate-800">
      <div class="flex items-center justify-between px-6 py-4
                  border-b border-slate-200 dark:border-slate-800">
        <h3 class="text-lg font-bold">${title}</h3>
        <button id="modalClose"
          class="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100
                 dark:hover:bg-slate-800 cursor-pointer">
          ${icon("x", "w-5 h-5")}
        </button>
      </div>
      <div class="p-6">${bodyHtml}</div>
    </div>
  </div>`;

/**
 * Mount a modal into the body and wire its close paths (X button, backdrop
 * click, Escape key). Returns a `close` function for callers to use after
 * a successful submit.
 */
export const openModal = (title, bodyHtml) => {
  const host = document.createElement("div");
  host.innerHTML = modalTemplate(title, bodyHtml);
  document.body.appendChild(host);

  const close = () => host.remove();

  host.querySelector("#modalClose")?.addEventListener("click", close);
  host.querySelector("#modalBackdrop")?.addEventListener("click", (e) => {
    if (e.target.id === "modalBackdrop") close();
  });
  document.addEventListener(
    "keydown",
    (e) => e.key === "Escape" && close(),
    { once: true },
  );

  return { host, close };
};
