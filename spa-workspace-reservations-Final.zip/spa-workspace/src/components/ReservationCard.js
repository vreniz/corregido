// ReservationCard.js
// Presentational card for a single reservation. It only renders markup;
// the action buttons carry data-attributes that the controller binds to.
// Which buttons appear is decided by the pure permission helpers.

import { statusLabel, statusBadge, canEdit, canCancel, canDelete }
  from "@utils/reservation.utils";
import { icon } from "@utils/icon";

/** A small labelled metadata row (icon + text). */
const meta = (ico, text) => `
  <div class="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
    ${icon(ico, "w-4 h-4 shrink-0")}<span>${text}</span>
  </div>`;

/** Action button factory; `tone` maps to colour. */
const actionBtn = (action, id, ico, label, tone) => {
  const tones = {
    edit: "text-slate-600 hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-700",
    cancel: "text-amber-600 hover:bg-amber-100 dark:hover:bg-amber-500/20",
    delete: "text-rose-600 hover:bg-rose-100 dark:hover:bg-rose-500/20",
    approve: "text-emerald-600 hover:bg-emerald-100 dark:hover:bg-emerald-500/20",
    reject: "text-rose-600 hover:bg-rose-100 dark:hover:bg-rose-500/20",
  };
  return `<button data-action="${action}" data-id="${id}" title="${label}"
    class="p-2 rounded-lg transition-colors cursor-pointer ${tones[tone]}">
    ${icon(ico, "w-4 h-4")}</button>`;
};

/**
 * Build the admin approve/reject controls, shown only for pending items.
 */
const adminControls = (r, user) => {
  if (user.role !== "admin" || r.status !== "pending") return "";
  return (
    actionBtn("approve", r.id, "check", "Approve", "approve") +
    actionBtn("reject", r.id, "ban", "Reject", "reject")
  );
};

/**
 * @param {object} reservation
 * @param {object} user        current session user (drives permissions)
 * @param {string} [ownerName] resolved owner label (admin view)
 * @param {number} [index]     used for the staggered entrance delay
 */
export default function ReservationCard(
  reservation,
  user,
  ownerName = "",
  index = 0,
) {
  const { id, workspace, date, startHour, endHour, reason, status } =
    reservation;

  // Compose the per-card actions from the permission helpers.
  const actions = [
    canEdit(reservation, user) &&
      actionBtn("edit", id, "edit", "Edit", "edit"),
    canCancel(reservation, user) &&
      actionBtn("cancel", id, "ban", "Cancel", "cancel"),
    canDelete(reservation, user) &&
      actionBtn("delete", id, "trash", "Delete", "delete"),
    adminControls(reservation, user),
  ]
    .filter(Boolean)
    .join("");

  return `
    <article style="animation-delay:${index * 60}ms"
      class="card-in rounded-2xl border border-slate-200 dark:border-slate-800
             bg-white dark:bg-slate-900 p-5 shadow-sm hover:shadow-md transition-shadow">
      <div class="flex items-start justify-between gap-3 mb-3">
        <h3 class="font-bold text-lg">${workspace}</h3>
        <span class="text-xs font-semibold px-2.5 py-1 rounded-full ${statusBadge(status)}">
          ${statusLabel(status)}
        </span>
      </div>
      ${ownerName ? meta("users", ownerName) : ""}
      <div class="space-y-1.5 mt-1">
        ${meta("calendar", date)}
        ${meta("clock", `${startHour} – ${endHour}`)}
        ${meta("doc", reason)}
      </div>
      <div class="flex items-center gap-1 mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
        ${actions || `<span class="text-xs text-slate-400">No actions available</span>`}
      </div>
    </article>`;
}
