// Layout.js
// Shared two-column shell: fixed sidebar + scrollable main area. Views pass
// their inner markup as a string. A topbar slot holds the page title and an
// optional action (e.g. "New reservation").

import Sidebar from "@components/Sidebar";

/**
 * @param {object} opts
 * @param {string} opts.title    page heading
 * @param {string} opts.content  inner HTML for the main panel
 * @param {string} [opts.action] optional right-aligned action markup
 */
export default function Layout({ title, content, action = "" }) {
  return `
    <div class="flex bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 min-h-screen">
      ${Sidebar()}
      <main class="flex-1 min-w-0">
        <header class="flex items-center justify-between gap-4 px-6 sm:px-8 py-5
                       border-b border-slate-200 dark:border-slate-800
                       bg-white/70 dark:bg-slate-900/60 backdrop-blur sticky top-0 z-10">
          <h1 class="text-xl sm:text-2xl font-bold tracking-tight">${title}</h1>
          <div>${action}</div>
        </header>
        <div class="p-6 sm:p-8">${content}</div>
      </main>
    </div>`;
}
