// router.js
// History API based SPA router. A route maps a path to a view (markup),
// an optional guard (access control), and an optional controller (wiring
// run after the markup is in the DOM). No hash routing is used.

import loginView from "@views/loginView";
import homeView from "@views/homeView";
import reservationsView from "@views/reservationsView";
import spacesView from "@views/spacesView";
import usersView from "@views/usersView";
import dashboardView from "@views/dashboardView";
import unauthorizedView from "@views/unauthorized";
import notFoundView from "@views/notFound";

import { loginController } from "@controllers/login.controller";
import { homeController } from "@controllers/home.controller";
import { reservationsController } from "@controllers/reservations.controller";
import { spacesController } from "@controllers/spaces.controller";
import { usersController } from "@controllers/users.controller";
import { dashboardController } from "@controllers/dashboard.controller";

import { requireAuth, requireRole } from "@guards/auth.guard";

// Route table. `guard` runs first; if it returns a path we redirect there.
const routes = {
  "/": { view: loginView, controller: loginController },
  "/home": { view: homeView, controller: homeController, guard: requireAuth },
  "/reservations": {
    view: reservationsView,
    controller: reservationsController,
    guard: requireAuth,
  },
  "/spaces": {
    view: spacesView,
    controller: spacesController,
    guard: requireRole("admin"),
  },
  "/users": {
    view: usersView,
    controller: usersController,
    guard: requireRole("admin"),
  },
  "/dashboard": {
    view: dashboardView,
    controller: dashboardController,
    guard: requireRole("admin"),
  },
  "/unauthorized": { view: unauthorizedView },
};

/**
 * Programmatic navigation. Pushes a new history entry, then re-renders.
 * Used by every in-app link/button instead of full page loads.
 */
export const navigateTo = (path) => {
  history.pushState({}, "", path);
  router();
};

/**
 * Resolve the current path to a route, falling back to the 404 view.
 */
const resolveRoute = (path) =>
  routes[path] || { view: notFoundView };

/**
 * Render pipeline:
 * 1) resolve route, 2) run guard (maybe redirect), 3) inject markup,
 * 4) play the enter animation, 5) run the controller.
 */
export const router = () => {
  const app = document.querySelector("#app");
  const path = window.location.pathname;
  const route = resolveRoute(path);

  // Guard check — a returned path means "access denied, go here".
  const redirect = route.guard?.();
  if (redirect) {
    navigateTo(redirect);
    return;
  }

  app.innerHTML = `<div class="view-enter">${route.view()}</div>`;
  route.controller?.();
};

// Handle browser back/forward buttons.
window.addEventListener("popstate", router);

/**
 * Intercept clicks on elements marked with `data-link` so internal links
 * navigate through the router instead of reloading the page.
 */
export const initLinkInterception = () => {
  document.body.addEventListener("click", (e) => {
    const link = e.target.closest("[data-link]");
    if (!link) return;
    e.preventDefault();
    navigateTo(link.getAttribute("href"));
  });
};
