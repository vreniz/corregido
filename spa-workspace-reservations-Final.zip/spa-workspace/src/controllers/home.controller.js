// home.controller.js
// Fills the home page after render: binds the sidebar, loads reservations
// scoped to the user's role, computes summary stats, and shows the most
// recent cards.

import ReservationCard from "@components/ReservationCard";
import { bindSidebar } from "@components/Sidebar";
import { getReservations, getReservationsByUser }
  from "@services/reservation.service";
import { getUsers } from "@services/user.service";
import { getSession } from "@/utils";

/** Count reservations by a given status. */
const countBy = (list, status) =>
  list.filter((r) => r.status === status).length;

/** Write computed numbers into the stat tiles. */
const renderStats = (list) => {
  document.querySelector("#statTotal").textContent = list.length;
  document.querySelector("#statPending").textContent = countBy(list, "pending");
  document.querySelector("#statApproved").textContent = countBy(list, "approved");
  document.querySelector("#statRejected").textContent = countBy(list, "rejected");
};

/** Build a userId -> name map so admin cards can show owners. */
const buildOwnerMap = async (isAdminUser) => {
  if (!isAdminUser) return {};
  const users = await getUsers();
  return Object.fromEntries(users.map((u) => [u.id, u.name]));
};

export const homeController = async () => {
  bindSidebar();
  const user = getSession();
  const container = document.querySelector("#recentContainer");

  try {
    // Admins see all; users see only their own (server-side filter).
    const list =
      user.role === "admin"
        ? await getReservations()
        : await getReservationsByUser(user.id);

    renderStats(list);

    const owners = await buildOwnerMap(user.role === "admin");
    const recent = [...list].slice(-6).reverse();

    container.innerHTML = recent.length
      ? recent
          .map((r, i) =>
            ReservationCard(r, user, owners[r.userId] || "", i),
          )
          .join("")
      : `<p class="text-slate-500">No reservations yet.</p>`;
  } catch {
    container.innerHTML =
      `<p class="text-rose-600">Failed to load reservations.</p>`;
  }
};
