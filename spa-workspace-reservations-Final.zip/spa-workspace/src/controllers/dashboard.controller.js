// dashboard.controller.js
// Admin statistics. Computes totals from reservations + spaces and renders
// two lightweight bar charts (status breakdown, top spaces) using plain
// divs so there's no charting dependency.

import { bindSidebar } from "@components/Sidebar";
import { getReservations } from "@services/reservation.service";
import { getSpaces } from "@services/space.service";

/** Count reservations by status. */
const countBy = (list, status) =>
  list.filter((r) => r.status === status).length;

/** A single labelled bar; width is a percentage of the max value. */
const bar = (label, value, max, color) => {
  const pct = max ? Math.round((value / max) * 100) : 0;
  return `
    <div>
      <div class="flex justify-between text-sm mb-1">
        <span class="font-medium">${label}</span>
        <span class="text-slate-500">${value}</span>
      </div>
      <div class="h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
        <div class="h-full ${color} rounded-full transition-all" style="width:${pct}%"></div>
      </div>
    </div>`;
};

/** Fill the four headline tiles. */
const renderTiles = (list, spaces) => {
  document.querySelector("#dTotal").textContent = list.length;
  document.querySelector("#dPending").textContent = countBy(list, "pending");
  document.querySelector("#dApproved").textContent = countBy(list, "approved");
  document.querySelector("#dSpaces").textContent = spaces.length;
};

/** Render the status breakdown chart. */
const renderStatusChart = (list) => {
  const statuses = [
    ["Pending", countBy(list, "pending"), "bg-amber-500"],
    ["Approved", countBy(list, "approved"), "bg-emerald-500"],
    ["Rejected", countBy(list, "rejected"), "bg-rose-500"],
    ["Cancelled", countBy(list, "cancelled"), "bg-slate-400"],
  ];
  const max = Math.max(...statuses.map((s) => s[1]), 1);
  document.querySelector("#statusChart").innerHTML = statuses
    .map(([label, value, color]) => bar(label, value, max, color))
    .join("");
};

/** Tally reservations per workspace and return sorted [name, count] pairs. */
const tallySpaces = (list) => {
  const counts = {};
  list.forEach((r) => {
    counts[r.workspace] = (counts[r.workspace] || 0) + 1;
  });
  return Object.entries(counts).sort((a, b) => b[1] - a[1]);
};

/** Render the most-booked-spaces chart. */
const renderSpaceChart = (list) => {
  const pairs = tallySpaces(list);
  const max = Math.max(...pairs.map((p) => p[1]), 1);
  document.querySelector("#spaceChart").innerHTML = pairs.length
    ? pairs.map(([name, count]) => bar(name, count, max, "bg-teal-500")).join("")
    : `<p class="text-slate-500">No data yet.</p>`;
};

export const dashboardController = async () => {
  bindSidebar();
  try {
    const [list, spaces] = await Promise.all([getReservations(), getSpaces()]);
    renderTiles(list, spaces);
    renderStatusChart(list);
    renderSpaceChart(list);
  } catch {
    document.querySelector("#statusChart").innerHTML =
      `<p class="text-rose-600">Failed to load statistics.</p>`;
  }
};
