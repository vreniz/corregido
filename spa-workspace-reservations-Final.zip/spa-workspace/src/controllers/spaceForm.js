// spaceForm.js
// Markup + helpers for the create/edit space modal (admin only).

const inputClass =
  "mt-1 w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 " +
  "bg-white dark:bg-slate-900 focus:ring-2 focus:ring-teal-500 outline-none transition";

const field = (label, inputHtml) => `
  <label class="block">
    <span class="text-sm font-medium text-slate-700 dark:text-slate-300">${label}</span>
    ${inputHtml}
  </label>`;

const TYPES = ["Meeting Room", "Private Office", "Coworking", "Auditorium"];

/** Build the space form, pre-filled when editing. */
export const spaceForm = (data = {}) => {
  const s = {
    name: data.name || "",
    type: data.type || "",
    capacity: data.capacity || "",
    location: data.location || "",
    status: data.status || "available",
  };
  const typeOpts = TYPES.map(
    (t) => `<option value="${t}" ${t === s.type ? "selected" : ""}>${t}</option>`,
  ).join("");

  return `
    <form id="spaceForm" class="space-y-4" novalidate>
      ${field("Name", `<input id="s_name" type="text" value="${s.name}" class="${inputClass}" />`)}
      ${field(
        "Type",
        `<select id="s_type" class="${inputClass}">
           <option value="" disabled ${s.type ? "" : "selected"}>Select…</option>
           ${typeOpts}
         </select>`,
      )}
      <div class="grid grid-cols-2 gap-3">
        ${field("Capacity", `<input id="s_capacity" type="number" min="1" value="${s.capacity}" class="${inputClass}" />`)}
        ${field(
          "Status",
          `<select id="s_status" class="${inputClass}">
             <option value="available" ${s.status === "available" ? "selected" : ""}>Available</option>
             <option value="unavailable" ${s.status === "unavailable" ? "selected" : ""}>Unavailable</option>
           </select>`,
        )}
      </div>
      ${field("Location", `<input id="s_location" type="text" value="${s.location}" class="${inputClass}" />`)}
      <button id="submitSpace" type="button"
        class="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white
               font-semibold transition cursor-pointer">
        Save space
      </button>
    </form>`;
};

/** Read the space form into an object (capacity coerced to number). */
export const readSpaceForm = () => ({
  name: document.querySelector("#s_name").value.trim(),
  type: document.querySelector("#s_type").value,
  capacity: Number(document.querySelector("#s_capacity").value),
  location: document.querySelector("#s_location").value.trim(),
  status: document.querySelector("#s_status").value,
});

/** Validate the space form; returns an error string or null. */
export const validateSpace = (data) => {
  if (!data.name) return "Name is required.";
  if (!data.type) return "Please select a type.";
  if (!data.capacity || data.capacity < 1) return "Capacity must be at least 1.";
  if (!data.location) return "Location is required.";
  return null;
};
