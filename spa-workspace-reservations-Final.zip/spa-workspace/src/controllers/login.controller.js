// login.controller.js
// Wires the login form: validates input, shows an immediate loading state
// on submit, persists the session on success, and on failure fully resets
// the form and returns focus to the email field.

import { login } from "@services/auth.service";
import { saveSession } from "@/utils";
import { showToast } from "@utils/toast";
import { navigateTo } from "@router/router";

/** Toggle the button between idle and loading (disabled + spinner). */
const setLoading = (form, loading) => {
  const btn = form.querySelector("#submitBtn");
  const label = form.querySelector("#submitLabel");
  const spinner = form.querySelector(".spin");
  btn.disabled = loading;
  label.textContent = loading ? "Signing in…" : "Sign in";
  spinner.classList.toggle("hidden", !loading);
};

/** Reset the form and restore focus to email after a failed attempt. */
const resetForm = (form) => {
  form.reset();
  setLoading(form, false);
  form.querySelector("#email").focus();
};

/**
 * Attempt authentication for the given credentials. Returns true on
 * success (caller navigates), false otherwise. Kept small to hold the
 * cyclomatic complexity of the submit handler down.
 */
const attemptLogin = async (email, password) => {
  const user = await login(email, password);
  if (!user) return false;
  saveSession({ id: user.id, name: user.name, role: user.role });
  return true;
};

export const loginController = () => {
  const form = document.querySelector("#loginForm");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = form.email.value.trim();
    const password = form.password.value.trim();

    // Immediate visual feedback before the network call.
    setLoading(form, true);

    try {
      const ok = await attemptLogin(email, password);
      if (ok) {
        showToast("Welcome back!", "success");
        navigateTo("/home");
        return;
      }
      showToast("Invalid credentials", "error");
      resetForm(form);
    } catch {
      showToast("Could not reach the server", "error");
      resetForm(form);
    }
  });

  // Focus email on mount for a faster start.
  form.querySelector("#email")?.focus();
};
