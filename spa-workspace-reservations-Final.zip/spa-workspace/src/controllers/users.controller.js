// users.controller.js
// Admin-only: render the list of registered users in a read-only table.

import { bindSidebar } from "@components/Sidebar";
import { getUsers } from "@services/user.service";
import { icon } from "@utils/icon";

/** Role badge for the table. */
const roleBadge = (role) => {
  const admin = role === "admin";
  const cls = admin
    ? "bg-teal-100 text-teal-700 dark:bg-teal-500/15 dark:text-teal-300"
    : "bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300";
  return `<span class="text-xs font-semibold px-2 py-1 rounded-full ${cls} capitalize">${role}</span>`;
};

/** One user row. */
const row = (u) => `
  <tr class="border-t border-slate-100 dark:border-slate-800">
    <td class="px-4 py-3 text-slate-400">#${u.id}</td>
    <td class="px-4 py-3 font-medium">${u.name}</td>
    <td class="px-4 py-3 text-slate-500 dark:text-slate-400">
      <span class="inline-flex items-center gap-2">${icon("mail", "w-4 h-4")}${u.email}</span>
    </td>
    <td class="px-4 py-3">${roleBadge(u.role)}</td>
  </tr>`;

/** Render the users table from API data. */
const renderTable = (users) => {
  document.querySelector("#usersContainer").innerHTML = `
    <table class="w-full text-sm text-left">
      <thead class="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400">
        <tr>
          <th class="px-4 py-3 font-semibold">ID</th>
          <th class="px-4 py-3 font-semibold">Name</th>
          <th class="px-4 py-3 font-semibold">Email</th>
          <th class="px-4 py-3 font-semibold">Role</th>
        </tr>
      </thead>
      <tbody>${users.map(row).join("")}</tbody>
    </table>`;
};

export const usersController = async () => {
  bindSidebar();
  try {
    const users = await getUsers();
    renderTable(users);
  } catch {
    document.querySelector("#usersContainer").innerHTML =
      `<p class="p-6 text-rose-600">Failed to load users.</p>`;
  }
};
