// main.js
// Application bootstrap. Runs once on load: pulls in styles, loads the
// display fonts, applies the saved theme, wires global click interception
// for SPA links, prepares the toast container, and renders the first route.

import "@/style.css";
import { router, initLinkInterception } from "@router/router";
import { initTheme } from "@utils/theme";
import { initToastRoot } from "@utils/toast";

/** Inject Google Fonts once, before first paint of text. */
const loadFonts = () => {
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href =
    "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap";
  document.head.appendChild(link);
};

// Kick everything off after the DOM is parsed.
document.addEventListener("DOMContentLoaded", () => {
  loadFonts();
  initTheme();
  initToastRoot();
  initLinkInterception();
  router();
});
