// dashboardView.js
// Admin-only statistics page. Renders empty stat tiles and a simple
// status-breakdown bar area; the controller computes the numbers from the
// reservations data and injects them.

import Layout from "@components/Layout";
import { icon } from "@utils/icon";

const tile = (id, label, ico, tint) => `
  <div class="rounded-2xl border border-slate-200 dark:border-slate-800
              bg-white dark:bg-slate-900 p-5">
    <div class="flex items-center justify-between">
      <p class="text-sm text-slate-500 dark:text-slate-400">${label}</p>
      <span class="p-2 rounded-lg ${tint}">${icon(ico, "w-5 h-5")}</span>
    </div>
    <p id="${id}" class="text-3xl font-bold mt-3">—</p>
  </div>`;

export default function dashboardView() {
  const content = `
    <div class="space-y-8">
      <section class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        ${tile("dTotal", "Total reservations", "grid", "bg-teal-50 dark:bg-teal-500/10 text-teal-600 dark:text-teal-400")}
        ${tile("dPending", "Pending", "clock", "bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400")}
        ${tile("dApproved", "Approved", "check", "bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400")}
        ${tile("dSpaces", "Spaces", "layers", "bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400")}
      </section>

      <section class="rounded-2xl border border-slate-200 dark:border-slate-800
                      bg-white dark:bg-slate-900 p-6">
        <h2 class="text-lg font-bold mb-4">Reservations by status</h2>
        <div id="statusChart" class="space-y-3">
          <p class="text-slate-500">Loading…</p>
        </div>
      </section>

      <section class="rounded-2xl border border-slate-200 dark:border-slate-800
                      bg-white dark:bg-slate-900 p-6">
        <h2 class="text-lg font-bold mb-4">Most booked spaces</h2>
        <div id="spaceChart" class="space-y-3">
          <p class="text-slate-500">Loading…</p>
        </div>
      </section>
    </div>`;

  return Layout({ title: "Dashboard", content });
}
