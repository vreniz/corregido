// loginView.js
// Login screen. Pure markup returned to the router; the controller
// (login.controller.js) handles submit, loading state, and errors.
// The router runs the controller after this markup is mounted.

import { icon } from "@utils/icon";

export default function loginView() {
  return `
    <div class="min-h-screen grid lg:grid-cols-2 bg-slate-100 dark:bg-slate-950">

      <!-- Brand / hero panel (hidden on small screens) -->
      <div class="hidden lg:flex flex-col justify-between p-12
                  bg-gradient-to-br from-teal-700 via-teal-800 to-slate-900 text-white">
        <div class="flex items-center gap-2">
          ${icon("calendar", "w-8 h-8 text-teal-300")}
          <span class="text-2xl font-bold">WorkSpace</span>
        </div>
        <div>
          <h2 class="text-4xl font-bold leading-tight mb-4">
            Book shared spaces<br/>without the chaos.
          </h2>
          <p class="text-teal-100/80 max-w-sm">
            Reserve meeting rooms, offices and auditoriums. Admins keep
            every booking organised in one place.
          </p>
        </div>
        <p class="text-xs text-teal-200/60">© 2026 WorkSpace Reservations</p>
      </div>

      <!-- Form panel -->
      <div class="flex items-center justify-center p-6 sm:p-10">
        <div class="w-full max-w-sm">
          <div class="lg:hidden flex items-center gap-2 mb-8 text-teal-700 dark:text-teal-400">
            ${icon("calendar", "w-7 h-7")}
            <span class="text-xl font-bold">WorkSpace</span>
          </div>

          <h1 class="text-3xl font-bold mb-1 text-slate-900 dark:text-white">Welcome back</h1>
          <p class="text-slate-500 dark:text-slate-400 mb-8">Sign in to manage your reservations.</p>

          <form id="loginForm" class="space-y-4" novalidate>
            <label class="block">
              <span class="text-sm font-medium text-slate-700 dark:text-slate-300">Email</span>
              <div class="relative mt-1">
                <span class="absolute inset-y-0 left-3 flex items-center text-slate-400">
                  ${icon("mail", "w-5 h-5")}
                </span>
                <input id="email" name="email" type="email" autocomplete="username"
                  placeholder="admin@test.com"
                  class="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700
                         bg-white dark:bg-slate-900 text-slate-900 dark:text-white
                         focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition" />
              </div>
            </label>

            <label class="block">
              <span class="text-sm font-medium text-slate-700 dark:text-slate-300">Password</span>
              <div class="relative mt-1">
                <span class="absolute inset-y-0 left-3 flex items-center text-slate-400">
                  ${icon("lock", "w-5 h-5")}
                </span>
                <input id="password" name="password" type="password" autocomplete="current-password"
                  placeholder="••••••••"
                  class="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700
                         bg-white dark:bg-slate-900 text-slate-900 dark:text-white
                         focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition" />
              </div>
            </label>

            <button id="submitBtn" type="submit"
              class="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl
                     bg-teal-600 hover:bg-teal-700 text-white font-semibold
                     transition-colors disabled:opacity-70 disabled:cursor-not-allowed cursor-pointer">
              <span id="submitLabel">Sign in</span>
              ${icon("spinner", "w-5 h-5 spin hidden")}
            </button>
          </form>

          <div class="mt-6 text-xs text-slate-400 space-y-1">
            <p class="font-medium text-slate-500 dark:text-slate-400">Demo accounts</p>
            <p>admin@test.com · Admin123*</p>
            <p>user@test.com · User123*</p>
          </div>
        </div>
      </div>
    </div>`;
}
