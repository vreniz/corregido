// reservationsView.js
// Full reservations management page. The view supplies the toolbar
// (search box, date filter, "New" button) and an empty grid; the
// controller fetches data, renders cards, and binds all interactions.

import Layout from "@components/Layout";
import { isAdmin } from "@/utils";
import { icon } from "@utils/icon";

export default function reservationsView() {
  const scopeNote = isAdmin()
    ? "Showing all reservations"
    : "Showing only your reservations";

  // Top-right action button opens the create modal (bound in controller).
  const action = `
    <button id="newReservationBtn"
      class="inline-flex items-center gap-2 px-4 py-2 rounded-xl
             bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold
             transition-colors cursor-pointer">
      ${icon("plus", "w-4 h-4")} New reservation
    </button>`;

  const content = `
    <div class="space-y-6">
      <!-- Filters: live search + date filter (bonus features) -->
      <div class="flex flex-col sm:flex-row gap-3">
        <div class="relative flex-1">
          <span class="absolute inset-y-0 left-3 flex items-center text-slate-400">
            ${icon("search", "w-5 h-5")}
          </span>
          <input id="searchInput" type="search" placeholder="Search by space or reason…"
            class="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700
                   bg-white dark:bg-slate-900 focus:ring-2 focus:ring-teal-500 outline-none transition" />
        </div>
        <input id="dateFilter" type="date"
          class="px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700
                 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-teal-500 outline-none transition" />
        <button id="clearFilters"
          class="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700
                 text-sm font-medium hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer">
          Clear
        </button>
      </div>

      <p class="text-sm text-slate-500 dark:text-slate-400">${scopeNote}</p>

      <div id="reservationsContainer" class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        <p class="text-slate-500">Loading reservations…</p>
      </div>
    </div>`;

  return Layout({ title: "Reservations", content, action });
}
