// unauthorized.js
// Shown by the role guard when a user reaches a route their role can't
// access. Offers a single way back to a page they can use.

import { icon } from "@utils/icon";

export default function unauthorizedView() {
  return `
    <div class="min-h-screen flex flex-col items-center justify-center
                bg-slate-100 dark:bg-slate-950 text-center px-4">
      <span class="p-4 rounded-2xl bg-rose-100 dark:bg-rose-500/15 text-rose-600 dark:text-rose-400 mb-6">
        ${icon("ban", "w-10 h-10")}
      </span>
      <h1 class="text-5xl font-bold text-slate-800 dark:text-white">403</h1>
      <h2 class="text-2xl font-semibold text-slate-700 dark:text-slate-200 mt-3">
        Access denied
      </h2>
      <p class="text-slate-500 dark:text-slate-400 mt-2 max-w-md">
        You don't have permission to view this page. This area is restricted
        to administrators.
      </p>
      <a href="/home" data-link
        class="mt-6 inline-flex items-center gap-2 px-6 py-3 rounded-xl
               bg-teal-600 hover:bg-teal-700 text-white font-semibold transition cursor-pointer">
        ${icon("home", "w-5 h-5")} Back to home
      </a>
    </div>`;
}
