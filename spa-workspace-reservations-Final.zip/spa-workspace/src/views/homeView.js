// homeView.js
// Authenticated landing page. Shows a welcome header, quick stat tiles
// (filled by the controller), and a recent-reservations container. Uses
// the shared Layout for the sidebar + topbar.

import Layout from "@components/Layout";
import { getSession, isAdmin } from "@/utils";
import { icon } from "@utils/icon";

/** Skeleton stat tile; the controller swaps in real numbers. */
const statTile = (id, label, ico) => `
  <div class="rounded-2xl border border-slate-200 dark:border-slate-800
              bg-white dark:bg-slate-900 p-5 flex items-center gap-4">
    <span class="p-3 rounded-xl bg-teal-50 dark:bg-teal-500/10 text-teal-600 dark:text-teal-400">
      ${icon(ico, "w-6 h-6")}
    </span>
    <div>
      <p id="${id}" class="text-2xl font-bold leading-none">—</p>
      <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">${label}</p>
    </div>
  </div>`;

export default function homeView() {
  const user = getSession();
  const scope = isAdmin() ? "all reservations" : "your reservations";

  const content = `
    <div class="space-y-8">
      <section>
        <h2 class="text-lg font-semibold text-slate-500 dark:text-slate-400">
          Welcome back,
        </h2>
        <p class="text-3xl font-bold">${user?.name}</p>
        <p class="text-sm text-slate-500 dark:text-slate-400 mt-1 capitalize">
          Role: ${user?.role} · viewing ${scope}
        </p>
      </section>

      <section class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        ${statTile("statTotal", "Total", "grid")}
        ${statTile("statPending", "Pending", "clock")}
        ${statTile("statApproved", "Approved", "check")}
        ${statTile("statRejected", "Rejected", "ban")}
      </section>

      <section>
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-xl font-bold">Recent reservations</h2>
          <a href="/reservations" data-link
            class="text-sm font-semibold text-teal-600 dark:text-teal-400 hover:underline">
            View all →
          </a>
        </div>
        <div id="recentContainer" class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          <p class="text-slate-500">Loading…</p>
        </div>
      </section>
    </div>`;

  return Layout({ title: "Home", content });
}
