// usersView.js
// Admin-only view listing every registered user. The controller fills the
// container with a table once /users resolves.

import Layout from "@components/Layout";

export default function usersView() {
  const content = `
    <div id="usersContainer"
         class="rounded-2xl border border-slate-200 dark:border-slate-800
                bg-white dark:bg-slate-900 overflow-hidden">
      <p class="p-6 text-slate-500">Loading users…</p>
    </div>`;

  return Layout({ title: "Users", content });
}
