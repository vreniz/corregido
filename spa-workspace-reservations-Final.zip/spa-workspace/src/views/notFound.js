// notFound.js
// Catch-all 404 view. Returned by the router when no route matches the
// current path. The button uses data-link so it routes via History API.

import { icon } from "@utils/icon";

export default function notFoundView() {
  return `
    <div class="min-h-screen flex flex-col items-center justify-center
                bg-slate-100 dark:bg-slate-950 text-center px-4">
      <span class="p-4 rounded-2xl bg-slate-200 dark:bg-slate-800 text-slate-500 mb-6">
        ${icon("search", "w-10 h-10")}
      </span>
      <h1 class="text-7xl font-bold text-slate-800 dark:text-white">404</h1>
      <h2 class="text-2xl font-semibold text-slate-700 dark:text-slate-200 mt-3">
        Page not found
      </h2>
      <p class="text-slate-500 dark:text-slate-400 mt-2 max-w-md">
        The page you're looking for doesn't exist or has been moved.
      </p>
      <a href="/home" data-link
        class="mt-6 inline-flex items-center gap-2 px-6 py-3 rounded-xl
               bg-teal-600 hover:bg-teal-700 text-white font-semibold transition cursor-pointer">
        ${icon("home", "w-5 h-5")} Back to home
      </a>
    </div>`;
}
