// spacesView.js
// Admin-only workspace management page. Provides a "New space" action and
// a container the controller fills with a table of spaces.

import Layout from "@components/Layout";
import { icon } from "@utils/icon";

export default function spacesView() {
  const action = `
    <button id="newSpaceBtn"
      class="inline-flex items-center gap-2 px-4 py-2 rounded-xl
             bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold
             transition-colors cursor-pointer">
      ${icon("plus", "w-4 h-4")} New space
    </button>`;

  const content = `
    <div id="spacesContainer"
         class="rounded-2xl border border-slate-200 dark:border-slate-800
                bg-white dark:bg-slate-900 overflow-hidden">
      <p class="p-6 text-slate-500">Loading spaces…</p>
    </div>`;

  return Layout({ title: "Spaces", content, action });
}
