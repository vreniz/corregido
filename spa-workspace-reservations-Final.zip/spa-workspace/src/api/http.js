// http.js
// Tiny fetch wrapper around the json-server REST API. Every method funnels
// through `request`, which sets JSON headers, checks the response status,
// and surfaces a single error type to callers.

const API_URL = "http://localhost:3001";

/**
 * Core request. Merges default JSON headers with caller options, then
 * throws on any non-2xx status so callers can rely on try/catch.
 */
const request = async (endpoint, options = {}) => {
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });

    if (!response.ok) {
      throw new Error(`HTTP Error ${response.status}`);
    }

    // DELETE responses can be empty; guard JSON parsing.
    const text = await response.text();
    return text ? JSON.parse(text) : null;
  } catch (error) {
    console.error("[http]", error);
    throw error;
  }
};

// Verb helpers — thin shells over `request` for readability at call sites.
export const http = {
  get: (endpoint) => request(endpoint),
  post: (endpoint, data) =>
    request(endpoint, { method: "POST", body: JSON.stringify(data) }),
  put: (endpoint, data) =>
    request(endpoint, { method: "PUT", body: JSON.stringify(data) }),
  patch: (endpoint, data) =>
    request(endpoint, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (endpoint) => request(endpoint, { method: "DELETE" }),
};
